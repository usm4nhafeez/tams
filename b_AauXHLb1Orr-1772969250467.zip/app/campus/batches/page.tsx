'use client'

import { useState } from 'react'
import { Plus, Archive, Pencil, Trash2, Users, MoreHorizontal } from 'lucide-react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { Skeleton } from '@/components/ui/skeleton'
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog'
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu'
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from '@/components/ui/alert-dialog'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { useBatches, useBatchMutations } from '@/lib/queries'
import type { Batch, BatchFormData } from '@/lib/types'

function BatchFormDialog({
  open,
  onOpenChange,
  batch,
  onSubmit,
}: {
  open: boolean
  onOpenChange: (open: boolean) => void
  batch?: Batch | null
  onSubmit: (data: BatchFormData) => Promise<void>
}) {
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [formData, setFormData] = useState<BatchFormData>({
    name: batch?.name ?? '',
    grade: batch?.grade ?? '',
    academicYear: batch?.academicYear ?? new Date().getFullYear().toString(),
    monthlyFee: batch?.monthlyFee ?? 0,
  })

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsSubmitting(true)
    await onSubmit(formData)
    setIsSubmitting(false)
    onOpenChange(false)
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>{batch ? 'Edit Batch' : 'Create New Batch'}</DialogTitle>
          <DialogDescription>
            {batch
              ? 'Update the batch details below.'
              : 'Fill in the details to create a new batch.'}
          </DialogDescription>
        </DialogHeader>
        <form onSubmit={handleSubmit}>
          <div className="grid gap-4 py-4">
            <div className="grid gap-2">
              <Label htmlFor="name">Batch Name</Label>
              <Input
                id="name"
                placeholder="e.g., Morning Batch A"
                value={formData.name}
                onChange={(e) =>
                  setFormData({ ...formData, name: e.target.value })
                }
                required
              />
            </div>
            <div className="grid gap-2">
              <Label htmlFor="grade">Grade / Class</Label>
              <Input
                id="grade"
                placeholder="e.g., 10th Standard"
                value={formData.grade}
                onChange={(e) =>
                  setFormData({ ...formData, grade: e.target.value })
                }
                required
              />
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div className="grid gap-2">
                <Label htmlFor="academicYear">Academic Year</Label>
                <Input
                  id="academicYear"
                  placeholder="e.g., 2024"
                  value={formData.academicYear}
                  onChange={(e) =>
                    setFormData({ ...formData, academicYear: e.target.value })
                  }
                  required
                />
              </div>
              <div className="grid gap-2">
                <Label htmlFor="monthlyFee">Monthly Fee (₹)</Label>
                <Input
                  id="monthlyFee"
                  type="number"
                  min="0"
                  placeholder="e.g., 2000"
                  value={formData.monthlyFee}
                  onChange={(e) =>
                    setFormData({
                      ...formData,
                      monthlyFee: parseInt(e.target.value) || 0,
                    })
                  }
                  required
                />
              </div>
            </div>
          </div>
          <DialogFooter>
            <Button
              type="button"
              variant="outline"
              onClick={() => onOpenChange(false)}
            >
              Cancel
            </Button>
            <Button type="submit" disabled={isSubmitting}>
              {isSubmitting ? 'Saving...' : batch ? 'Update Batch' : 'Create Batch'}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  )
}

function BatchCard({
  batch,
  onEdit,
  onArchive,
  onDelete,
}: {
  batch: Batch
  onEdit: () => void
  onArchive: () => void
  onDelete: () => void
}) {
  return (
    <Card className={batch.isArchived ? 'opacity-60' : ''}>
      <CardHeader className="flex flex-row items-start justify-between pb-2">
        <div className="space-y-1">
          <CardTitle className="text-lg">{batch.name}</CardTitle>
          <CardDescription>{batch.grade}</CardDescription>
        </div>
        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <Button variant="ghost" size="icon" className="size-8">
              <MoreHorizontal className="size-4" />
              <span className="sr-only">Open menu</span>
            </Button>
          </DropdownMenuTrigger>
          <DropdownMenuContent align="end">
            <DropdownMenuItem onClick={onEdit}>
              <Pencil className="mr-2 size-4" />
              Edit
            </DropdownMenuItem>
            <DropdownMenuItem onClick={onArchive}>
              <Archive className="mr-2 size-4" />
              {batch.isArchived ? 'Unarchive' : 'Archive'}
            </DropdownMenuItem>
            <DropdownMenuSeparator />
            <DropdownMenuItem
              onClick={onDelete}
              className="text-destructive focus:text-destructive"
            >
              <Trash2 className="mr-2 size-4" />
              Delete
            </DropdownMenuItem>
          </DropdownMenuContent>
        </DropdownMenu>
      </CardHeader>
      <CardContent>
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2 text-sm text-muted-foreground">
            <Users className="size-4" />
            <span>{batch.studentCount ?? 0} students</span>
          </div>
          <div className="flex items-center gap-2">
            <Badge variant="secondary">{batch.academicYear}</Badge>
            {batch.isArchived && <Badge variant="outline">Archived</Badge>}
          </div>
        </div>
        <div className="mt-4 pt-4 border-t">
          <div className="flex items-center justify-between text-sm">
            <span className="text-muted-foreground">Monthly Fee</span>
            <span className="font-medium">
              ₹{batch.monthlyFee.toLocaleString('en-IN')}
            </span>
          </div>
        </div>
      </CardContent>
    </Card>
  )
}

function BatchesSkeleton() {
  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <Skeleton className="h-8 w-32 mb-2" />
          <Skeleton className="h-4 w-48" />
        </div>
        <Skeleton className="h-10 w-32" />
      </div>
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
        {[1, 2, 3].map((i) => (
          <Skeleton key={i} className="h-48" />
        ))}
      </div>
    </div>
  )
}

export default function BatchesPage() {
  const { batches, isLoading, refresh } = useBatches()
  const { createBatch, updateBatch, archiveBatch, deleteBatch } = useBatchMutations()

  const [showForm, setShowForm] = useState(false)
  const [editingBatch, setEditingBatch] = useState<Batch | null>(null)
  const [deletingBatch, setDeletingBatch] = useState<Batch | null>(null)

  const handleCreate = async (data: BatchFormData) => {
    await createBatch(data)
    refresh()
  }

  const handleUpdate = async (data: BatchFormData) => {
    if (editingBatch) {
      await updateBatch(editingBatch.id, data)
      setEditingBatch(null)
      refresh()
    }
  }

  const handleArchive = async (batch: Batch) => {
    await archiveBatch(batch.id)
    refresh()
  }

  const handleDelete = async () => {
    if (deletingBatch) {
      await deleteBatch(deletingBatch.id)
      setDeletingBatch(null)
      refresh()
    }
  }

  if (isLoading) {
    return <BatchesSkeleton />
  }

  const activeBatches = batches.filter((b) => !b.isArchived)
  const archivedBatches = batches.filter((b) => b.isArchived)

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold tracking-tight">Batches</h1>
          <p className="text-muted-foreground">
            Manage your academy batches and classes
          </p>
        </div>
        <Button onClick={() => setShowForm(true)}>
          <Plus className="mr-2 size-4" />
          New Batch
        </Button>
      </div>

      {batches.length === 0 ? (
        <Card>
          <CardContent className="flex flex-col items-center justify-center py-12">
            <Users className="size-12 text-muted-foreground mb-4" />
            <h3 className="text-lg font-medium mb-2">No batches yet</h3>
            <p className="text-muted-foreground text-center mb-4">
              Get started by creating your first batch to organize students.
            </p>
            <Button onClick={() => setShowForm(true)}>
              <Plus className="mr-2 size-4" />
              Create Batch
            </Button>
          </CardContent>
        </Card>
      ) : (
        <>
          {activeBatches.length > 0 && (
            <div className="space-y-4">
              <h2 className="text-lg font-semibold">Active Batches</h2>
              <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
                {activeBatches.map((batch) => (
                  <BatchCard
                    key={batch.id}
                    batch={batch}
                    onEdit={() => setEditingBatch(batch)}
                    onArchive={() => handleArchive(batch)}
                    onDelete={() => setDeletingBatch(batch)}
                  />
                ))}
              </div>
            </div>
          )}

          {archivedBatches.length > 0 && (
            <div className="space-y-4">
              <h2 className="text-lg font-semibold text-muted-foreground">
                Archived Batches
              </h2>
              <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
                {archivedBatches.map((batch) => (
                  <BatchCard
                    key={batch.id}
                    batch={batch}
                    onEdit={() => setEditingBatch(batch)}
                    onArchive={() => handleArchive(batch)}
                    onDelete={() => setDeletingBatch(batch)}
                  />
                ))}
              </div>
            </div>
          )}
        </>
      )}

      {/* Create Dialog */}
      <BatchFormDialog
        open={showForm}
        onOpenChange={setShowForm}
        onSubmit={handleCreate}
      />

      {/* Edit Dialog */}
      <BatchFormDialog
        open={!!editingBatch}
        onOpenChange={(open) => !open && setEditingBatch(null)}
        batch={editingBatch}
        onSubmit={handleUpdate}
      />

      {/* Delete Confirmation */}
      <AlertDialog
        open={!!deletingBatch}
        onOpenChange={(open) => !open && setDeletingBatch(null)}
      >
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Delete Batch</AlertDialogTitle>
            <AlertDialogDescription>
              Are you sure you want to delete &quot;{deletingBatch?.name}&quot;? This
              action cannot be undone. All associated data will be permanently
              removed.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction
              onClick={handleDelete}
              className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
            >
              Delete
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  )
}
