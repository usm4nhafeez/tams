'use client'

import { useState } from 'react'
import { Plus, Pencil, Trash2, Users, MoreHorizontal, FolderOpen } from 'lucide-react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { Skeleton } from '@/components/ui/skeleton'
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog'
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu'
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from '@/components/ui/alert-dialog'
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { useBatches, useGroups, useGroupMutations } from '@/lib/queries'
import type { Group, GroupFormData } from '@/lib/types'

function GroupFormDialog({
  open,
  onOpenChange,
  group,
  onSubmit,
}: {
  open: boolean
  onOpenChange: (open: boolean) => void
  group?: Group | null
  onSubmit: (data: GroupFormData) => Promise<void>
}) {
  const { batches } = useBatches()
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [formData, setFormData] = useState<GroupFormData>({
    batchId: group?.batchId ?? '',
    name: group?.name ?? '',
  })

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsSubmitting(true)
    await onSubmit(formData)
    setIsSubmitting(false)
    onOpenChange(false)
  }

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>{group ? 'Edit Group' : 'Create New Group'}</DialogTitle>
          <DialogDescription>
            {group
              ? 'Update the group details below.'
              : 'Groups help you organize students within a batch.'}
          </DialogDescription>
        </DialogHeader>
        <form onSubmit={handleSubmit}>
          <div className="grid gap-4 py-4">
            <div className="grid gap-2">
              <Label htmlFor="batch">Batch</Label>
              <Select
                value={formData.batchId}
                onValueChange={(value) =>
                  setFormData({ ...formData, batchId: value })
                }
                required
              >
                <SelectTrigger>
                  <SelectValue placeholder="Select a batch" />
                </SelectTrigger>
                <SelectContent>
                  {batches
                    .filter((b) => !b.isArchived)
                    .map((batch) => (
                      <SelectItem key={batch.id} value={batch.id}>
                        {batch.name} ({batch.grade})
                      </SelectItem>
                    ))}
                </SelectContent>
              </Select>
            </div>
            <div className="grid gap-2">
              <Label htmlFor="name">Group Name</Label>
              <Input
                id="name"
                placeholder="e.g., Group A, Science Section"
                value={formData.name}
                onChange={(e) =>
                  setFormData({ ...formData, name: e.target.value })
                }
                required
              />
            </div>
          </div>
          <DialogFooter>
            <Button
              type="button"
              variant="outline"
              onClick={() => onOpenChange(false)}
            >
              Cancel
            </Button>
            <Button type="submit" disabled={isSubmitting || !formData.batchId}>
              {isSubmitting ? 'Saving...' : group ? 'Update Group' : 'Create Group'}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  )
}

function GroupCard({
  group,
  onEdit,
  onDelete,
}: {
  group: Group
  onEdit: () => void
  onDelete: () => void
}) {
  return (
    <Card>
      <CardHeader className="flex flex-row items-start justify-between pb-2">
        <div className="space-y-1">
          <CardTitle className="text-lg">{group.name}</CardTitle>
          <CardDescription>
            {group.batch?.name ?? 'Unknown Batch'}
          </CardDescription>
        </div>
        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <Button variant="ghost" size="icon" className="size-8">
              <MoreHorizontal className="size-4" />
              <span className="sr-only">Open menu</span>
            </Button>
          </DropdownMenuTrigger>
          <DropdownMenuContent align="end">
            <DropdownMenuItem onClick={onEdit}>
              <Pencil className="mr-2 size-4" />
              Edit
            </DropdownMenuItem>
            <DropdownMenuSeparator />
            <DropdownMenuItem
              onClick={onDelete}
              className="text-destructive focus:text-destructive"
            >
              <Trash2 className="mr-2 size-4" />
              Delete
            </DropdownMenuItem>
          </DropdownMenuContent>
        </DropdownMenu>
      </CardHeader>
      <CardContent>
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2 text-sm text-muted-foreground">
            <Users className="size-4" />
            <span>{group.studentCount ?? 0} students</span>
          </div>
          {group.batch && (
            <Badge variant="outline">{group.batch.grade}</Badge>
          )}
        </div>
      </CardContent>
    </Card>
  )
}

function GroupsSkeleton() {
  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <Skeleton className="h-8 w-32 mb-2" />
          <Skeleton className="h-4 w-48" />
        </div>
        <div className="flex gap-2">
          <Skeleton className="h-10 w-40" />
          <Skeleton className="h-10 w-32" />
        </div>
      </div>
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
        {[1, 2, 3, 4].map((i) => (
          <Skeleton key={i} className="h-36" />
        ))}
      </div>
    </div>
  )
}

export default function GroupsPage() {
  const { batches } = useBatches()
  const [selectedBatchId, setSelectedBatchId] = useState<string>('')
  const { groups, isLoading, refresh } = useGroups(selectedBatchId || undefined)
  const { createGroup, updateGroup, deleteGroup } = useGroupMutations()

  const [showForm, setShowForm] = useState(false)
  const [editingGroup, setEditingGroup] = useState<Group | null>(null)
  const [deletingGroup, setDeletingGroup] = useState<Group | null>(null)

  const handleCreate = async (data: GroupFormData) => {
    await createGroup(data, () => refresh())
  }

  const handleUpdate = async (data: GroupFormData) => {
    if (editingGroup) {
      await updateGroup(editingGroup.id, data, () => {
        setEditingGroup(null)
        refresh()
      })
    }
  }

  const handleDelete = async () => {
    if (deletingGroup) {
      await deleteGroup(deletingGroup.id, () => {
        setDeletingGroup(null)
        refresh()
      })
    }
  }

  if (isLoading) {
    return <GroupsSkeleton />
  }

  // Group by batch for display
  const groupsByBatch = groups.reduce(
    (acc, group) => {
      const batchName = group.batch?.name ?? 'Unknown Batch'
      if (!acc[batchName]) {
        acc[batchName] = []
      }
      acc[batchName].push(group)
      return acc
    },
    {} as Record<string, Group[]>
  )

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold tracking-tight">Groups</h1>
          <p className="text-muted-foreground">
            Organize students into groups within batches
          </p>
        </div>
        <div className="flex items-center gap-2">
          <Select
            value={selectedBatchId}
            onValueChange={setSelectedBatchId}
          >
            <SelectTrigger className="w-[180px]">
              <SelectValue placeholder="All Batches" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="">All Batches</SelectItem>
              {batches
                .filter((b) => !b.isArchived)
                .map((batch) => (
                  <SelectItem key={batch.id} value={batch.id}>
                    {batch.name}
                  </SelectItem>
                ))}
            </SelectContent>
          </Select>
          <Button onClick={() => setShowForm(true)}>
            <Plus className="mr-2 size-4" />
            New Group
          </Button>
        </div>
      </div>

      {groups.length === 0 ? (
        <Card>
          <CardContent className="flex flex-col items-center justify-center py-12">
            <FolderOpen className="size-12 text-muted-foreground mb-4" />
            <h3 className="text-lg font-medium mb-2">No groups yet</h3>
            <p className="text-muted-foreground text-center mb-4">
              {selectedBatchId
                ? 'No groups in this batch. Create one to organize students.'
                : 'Create groups to organize students within batches.'}
            </p>
            <Button onClick={() => setShowForm(true)}>
              <Plus className="mr-2 size-4" />
              Create Group
            </Button>
          </CardContent>
        </Card>
      ) : selectedBatchId ? (
        // Single batch view
        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
          {groups.map((group) => (
            <GroupCard
              key={group.id}
              group={group}
              onEdit={() => setEditingGroup(group)}
              onDelete={() => setDeletingGroup(group)}
            />
          ))}
        </div>
      ) : (
        // All batches view (grouped)
        <div className="space-y-8">
          {Object.entries(groupsByBatch).map(([batchName, batchGroups]) => (
            <div key={batchName} className="space-y-4">
              <h2 className="text-lg font-semibold">{batchName}</h2>
              <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
                {batchGroups.map((group) => (
                  <GroupCard
                    key={group.id}
                    group={group}
                    onEdit={() => setEditingGroup(group)}
                    onDelete={() => setDeletingGroup(group)}
                  />
                ))}
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Create Dialog */}
      <GroupFormDialog
        open={showForm}
        onOpenChange={setShowForm}
        onSubmit={handleCreate}
      />

      {/* Edit Dialog */}
      <GroupFormDialog
        open={!!editingGroup}
        onOpenChange={(open) => !open && setEditingGroup(null)}
        group={editingGroup}
        onSubmit={handleUpdate}
      />

      {/* Delete Confirmation */}
      <AlertDialog
        open={!!deletingGroup}
        onOpenChange={(open) => !open && setDeletingGroup(null)}
      >
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>Delete Group</AlertDialogTitle>
            <AlertDialogDescription>
              Are you sure you want to delete &quot;{deletingGroup?.name}&quot;?
              {(deletingGroup?.studentCount ?? 0) > 0 && (
                <span className="block mt-2 text-destructive">
                  This group has {deletingGroup?.studentCount} students. They
                  will be unassigned from this group.
                </span>
              )}
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>Cancel</AlertDialogCancel>
            <AlertDialogAction
              onClick={handleDelete}
              className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
            >
              Delete
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  )
}
