'use client'

import { useState, useMemo } from 'react'
import { format } from 'date-fns'
import { CalendarIcon, Check, X, Clock, Users, Save } from 'lucide-react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { Skeleton } from '@/components/ui/skeleton'
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar'
import { Calendar } from '@/components/ui/calendar'
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from '@/components/ui/popover'
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select'
import { ToggleGroup, ToggleGroupItem } from '@/components/ui/toggle-group'
import { cn } from '@/lib/utils'
import {
  useBatches,
  useGroups,
  useStudents,
  useAttendanceByDate,
  useAttendanceMutations,
} from '@/lib/queries'
import type { AttendanceStatus, AttendanceMarkPayload } from '@/lib/types'

function AttendanceSkeleton() {
  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <Skeleton className="h-8 w-48 mb-2" />
          <Skeleton className="h-4 w-64" />
        </div>
      </div>
      <div className="flex gap-4">
        <Skeleton className="h-10 w-48" />
        <Skeleton className="h-10 w-40" />
        <Skeleton className="h-10 w-40" />
      </div>
      <Skeleton className="h-96" />
    </div>
  )
}

function getInitials(firstName: string, lastName: string) {
  return `${firstName.charAt(0)}${lastName.charAt(0)}`.toUpperCase()
}

export default function AttendancePage() {
  const [selectedDate, setSelectedDate] = useState<Date>(new Date())
  const [selectedBatchId, setSelectedBatchId] = useState<string>('')
  const [selectedGroupId, setSelectedGroupId] = useState<string>('')
  const [isSaving, setIsSaving] = useState(false)

  const { batches, isLoading: batchesLoading } = useBatches()
  const { groups } = useGroups(selectedBatchId)
  const { students, isLoading: studentsLoading } = useStudents({
    batchId: selectedBatchId || undefined,
    groupId: selectedGroupId || undefined,
    status: 'active',
  })
  const dateStr = format(selectedDate, 'yyyy-MM-dd')
  const { records, isLoading: recordsLoading, refresh } = useAttendanceByDate(
    dateStr,
    { batchId: selectedBatchId || undefined }
  )
  const { markAttendance } = useAttendanceMutations()

  // Build attendance state from records
  const [attendanceState, setAttendanceState] = useState<
    Record<string, AttendanceStatus>
  >({})

  // Initialize attendance state from records
  useMemo(() => {
    const initial: Record<string, AttendanceStatus> = {}
    records.forEach((record) => {
      initial[record.studentId] = record.status
    })
    // Only update if different
    const currentKeys = Object.keys(attendanceState).sort().join(',')
    const newKeys = Object.keys(initial).sort().join(',')
    if (currentKeys !== newKeys || records.some(r => attendanceState[r.studentId] !== r.status)) {
      setAttendanceState(initial)
    }
  }, [records])

  const handleStatusChange = (studentId: string, status: AttendanceStatus) => {
    setAttendanceState((prev) => ({
      ...prev,
      [studentId]: status,
    }))
  }

  const handleMarkAll = (status: AttendanceStatus) => {
    const newState: Record<string, AttendanceStatus> = {}
    students.forEach((student) => {
      newState[student.id] = status
    })
    setAttendanceState(newState)
  }

  const handleSave = async () => {
    if (!selectedBatchId) return
    setIsSaving(true)

    const payload: AttendanceMarkPayload[] = Object.entries(attendanceState).map(
      ([studentId, status]) => ({
        studentId,
        status,
      })
    )

    await markAttendance(dateStr, payload, () => refresh())
    setIsSaving(false)
  }

  // Calculate stats
  const presentCount = Object.values(attendanceState).filter(
    (s) => s === 'present'
  ).length
  const absentCount = Object.values(attendanceState).filter(
    (s) => s === 'absent'
  ).length
  const leaveCount = Object.values(attendanceState).filter(
    (s) => s === 'leave'
  ).length
  const unmarkedCount = students.length - Object.keys(attendanceState).length

  const isLoading = batchesLoading || studentsLoading || recordsLoading

  if (isLoading && !selectedBatchId) {
    return <AttendanceSkeleton />
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold tracking-tight">Mark Attendance</h1>
          <p className="text-muted-foreground">
            Record daily attendance for students
          </p>
        </div>
        {selectedBatchId && students.length > 0 && (
          <Button onClick={handleSave} disabled={isSaving}>
            <Save className="mr-2 size-4" />
            {isSaving ? 'Saving...' : 'Save Attendance'}
          </Button>
        )}
      </div>

      {/* Filters */}
      <div className="flex flex-wrap gap-4">
        <Popover>
          <PopoverTrigger asChild>
            <Button
              variant="outline"
              className={cn(
                'w-[240px] justify-start text-left font-normal',
                !selectedDate && 'text-muted-foreground'
              )}
            >
              <CalendarIcon className="mr-2 size-4" />
              {selectedDate ? format(selectedDate, 'PPP') : 'Pick a date'}
            </Button>
          </PopoverTrigger>
          <PopoverContent className="w-auto p-0" align="start">
            <Calendar
              mode="single"
              selected={selectedDate}
              onSelect={(date) => date && setSelectedDate(date)}
              initialFocus
            />
          </PopoverContent>
        </Popover>

        <Select
          value={selectedBatchId}
          onValueChange={(value) => {
            setSelectedBatchId(value)
            setSelectedGroupId('')
            setAttendanceState({})
          }}
        >
          <SelectTrigger className="w-[200px]">
            <SelectValue placeholder="Select Batch" />
          </SelectTrigger>
          <SelectContent>
            {batches
              .filter((b) => !b.isArchived)
              .map((batch) => (
                <SelectItem key={batch.id} value={batch.id}>
                  {batch.name}
                </SelectItem>
              ))}
          </SelectContent>
        </Select>

        {selectedBatchId && groups.length > 0 && (
          <Select
            value={selectedGroupId}
            onValueChange={setSelectedGroupId}
          >
            <SelectTrigger className="w-[200px]">
              <SelectValue placeholder="All Groups" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="">All Groups</SelectItem>
              {groups.map((group) => (
                <SelectItem key={group.id} value={group.id}>
                  {group.name}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        )}
      </div>

      {!selectedBatchId ? (
        <Card>
          <CardContent className="flex flex-col items-center justify-center py-12">
            <Users className="size-12 text-muted-foreground mb-4" />
            <h3 className="text-lg font-medium mb-2">Select a Batch</h3>
            <p className="text-muted-foreground text-center">
              Choose a batch to start marking attendance for today.
            </p>
          </CardContent>
        </Card>
      ) : students.length === 0 ? (
        <Card>
          <CardContent className="flex flex-col items-center justify-center py-12">
            <Users className="size-12 text-muted-foreground mb-4" />
            <h3 className="text-lg font-medium mb-2">No Students</h3>
            <p className="text-muted-foreground text-center">
              No active students found in this batch.
            </p>
          </CardContent>
        </Card>
      ) : (
        <>
          {/* Quick Stats */}
          <div className="grid gap-4 sm:grid-cols-4">
            <Card>
              <CardContent className="pt-4">
                <div className="flex items-center justify-between">
                  <span className="text-sm text-muted-foreground">Present</span>
                  <Badge className="bg-success text-success-foreground">
                    {presentCount}
                  </Badge>
                </div>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="pt-4">
                <div className="flex items-center justify-between">
                  <span className="text-sm text-muted-foreground">Absent</span>
                  <Badge variant="destructive">{absentCount}</Badge>
                </div>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="pt-4">
                <div className="flex items-center justify-between">
                  <span className="text-sm text-muted-foreground">Leave</span>
                  <Badge className="bg-warning text-warning-foreground">
                    {leaveCount}
                  </Badge>
                </div>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="pt-4">
                <div className="flex items-center justify-between">
                  <span className="text-sm text-muted-foreground">Unmarked</span>
                  <Badge variant="secondary">{unmarkedCount}</Badge>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Bulk Actions */}
          <Card>
            <CardHeader className="pb-3">
              <div className="flex items-center justify-between">
                <CardTitle className="text-base">Quick Actions</CardTitle>
                <div className="flex gap-2">
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => handleMarkAll('present')}
                  >
                    <Check className="mr-1 size-3" />
                    Mark All Present
                  </Button>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => handleMarkAll('absent')}
                  >
                    <X className="mr-1 size-3" />
                    Mark All Absent
                  </Button>
                </div>
              </div>
            </CardHeader>
          </Card>

          {/* Student List */}
          <Card>
            <CardHeader>
              <CardTitle>Students ({students.length})</CardTitle>
              <CardDescription>
                Mark attendance by clicking P (Present), A (Absent), or L (Leave)
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-2">
                {students.map((student) => {
                  const status = attendanceState[student.id]
                  return (
                    <div
                      key={student.id}
                      className="flex items-center justify-between p-3 rounded-lg border hover:bg-muted/50 transition-colors"
                    >
                      <div className="flex items-center gap-3">
                        <Avatar className="size-10">
                          <AvatarImage
                            src={student.photoUrl}
                            alt={student.firstName}
                          />
                          <AvatarFallback>
                            {getInitials(student.firstName, student.lastName)}
                          </AvatarFallback>
                        </Avatar>
                        <div>
                          <p className="font-medium">
                            {student.firstName} {student.lastName}
                          </p>
                          <p className="text-sm text-muted-foreground">
                            {student.enrollmentId}
                            {student.group && ` - ${student.group.name}`}
                          </p>
                        </div>
                      </div>
                      <ToggleGroup
                        type="single"
                        value={status}
                        onValueChange={(value) => {
                          if (value) {
                            handleStatusChange(
                              student.id,
                              value as AttendanceStatus
                            )
                          }
                        }}
                      >
                        <ToggleGroupItem
                          value="present"
                          aria-label="Present"
                          className={cn(
                            'data-[state=on]:bg-success data-[state=on]:text-success-foreground'
                          )}
                        >
                          <Check className="size-4" />
                          <span className="ml-1 hidden sm:inline">P</span>
                        </ToggleGroupItem>
                        <ToggleGroupItem
                          value="absent"
                          aria-label="Absent"
                          className={cn(
                            'data-[state=on]:bg-destructive data-[state=on]:text-destructive-foreground'
                          )}
                        >
                          <X className="size-4" />
                          <span className="ml-1 hidden sm:inline">A</span>
                        </ToggleGroupItem>
                        <ToggleGroupItem
                          value="leave"
                          aria-label="Leave"
                          className={cn(
                            'data-[state=on]:bg-warning data-[state=on]:text-warning-foreground'
                          )}
                        >
                          <Clock className="size-4" />
                          <span className="ml-1 hidden sm:inline">L</span>
                        </ToggleGroupItem>
                      </ToggleGroup>
                    </div>
                  )
                })}
              </div>
            </CardContent>
          </Card>
        </>
      )}
    </div>
  )
}
