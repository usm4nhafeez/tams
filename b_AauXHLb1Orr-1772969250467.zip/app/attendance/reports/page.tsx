'use client'

import { useState } from 'react'
import { format, startOfMonth, endOfMonth, eachDayOfInterval, isWeekend } from 'date-fns'
import { CalendarIcon, Download, Users } from 'lucide-react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { Skeleton } from '@/components/ui/skeleton'
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar'
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select'
import { cn } from '@/lib/utils'
import {
  useBatches,
  useGroups,
  useAttendanceSummary,
} from '@/lib/queries'
import { attendanceApi } from '@/lib/api'
import { toast } from 'sonner'

function ReportsSkeleton() {
  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <Skeleton className="h-8 w-48 mb-2" />
          <Skeleton className="h-4 w-64" />
        </div>
      </div>
      <div className="flex gap-4">
        <Skeleton className="h-10 w-40" />
        <Skeleton className="h-10 w-40" />
        <Skeleton className="h-10 w-40" />
      </div>
      <Skeleton className="h-96" />
    </div>
  )
}

function getInitials(firstName: string, lastName: string) {
  return `${firstName.charAt(0)}${lastName.charAt(0)}`.toUpperCase()
}

// Generate month options for the last 12 months
function getMonthOptions() {
  const options = []
  const today = new Date()
  for (let i = 0; i < 12; i++) {
    const date = new Date(today.getFullYear(), today.getMonth() - i, 1)
    options.push({
      value: format(date, 'yyyy-MM'),
      label: format(date, 'MMMM yyyy'),
    })
  }
  return options
}

export default function AttendanceReportsPage() {
  const [selectedMonth, setSelectedMonth] = useState(
    format(new Date(), 'yyyy-MM')
  )
  const [selectedBatchId, setSelectedBatchId] = useState<string>('')
  const [selectedGroupId, setSelectedGroupId] = useState<string>('')
  const [isExporting, setIsExporting] = useState(false)

  const { batches, isLoading: batchesLoading } = useBatches()
  const { groups } = useGroups(selectedBatchId)
  const { summary, isLoading: summaryLoading } = useAttendanceSummary({
    batchId: selectedBatchId || undefined,
    groupId: selectedGroupId || undefined,
    month: selectedMonth,
  })

  const monthOptions = getMonthOptions()

  // Get days in the selected month (excluding weekends optionally)
  const monthDate = new Date(selectedMonth + '-01')
  const daysInMonth = eachDayOfInterval({
    start: startOfMonth(monthDate),
    end: endOfMonth(monthDate),
  }).filter((date) => !isWeekend(date))

  const handleExport = async () => {
    setIsExporting(true)
    try {
      const response = await attendanceApi.exportPdf({
        batchId: selectedBatchId || undefined,
        groupId: selectedGroupId || undefined,
        month: selectedMonth,
      })
      if (response.success && response.data?.pdfUrl) {
        // In Electron, this would open the PDF
        window.open(response.data.pdfUrl, '_blank')
        toast.success('Report exported successfully')
      } else {
        toast.error(response.error || 'Failed to export report')
      }
    } catch {
      toast.error('Failed to export report')
    }
    setIsExporting(false)
  }

  const isLoading = batchesLoading || summaryLoading

  if (isLoading && !selectedBatchId) {
    return <ReportsSkeleton />
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold tracking-tight">Attendance Reports</h1>
          <p className="text-muted-foreground">
            View and export monthly attendance reports
          </p>
        </div>
        {selectedBatchId && summary && summary.length > 0 && (
          <Button onClick={handleExport} disabled={isExporting}>
            <Download className="mr-2 size-4" />
            {isExporting ? 'Exporting...' : 'Export PDF'}
          </Button>
        )}
      </div>

      {/* Filters */}
      <div className="flex flex-wrap gap-4">
        <Select value={selectedMonth} onValueChange={setSelectedMonth}>
          <SelectTrigger className="w-[200px]">
            <CalendarIcon className="mr-2 size-4" />
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            {monthOptions.map((option) => (
              <SelectItem key={option.value} value={option.value}>
                {option.label}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>

        <Select
          value={selectedBatchId}
          onValueChange={(value) => {
            setSelectedBatchId(value)
            setSelectedGroupId('')
          }}
        >
          <SelectTrigger className="w-[200px]">
            <SelectValue placeholder="Select Batch" />
          </SelectTrigger>
          <SelectContent>
            {batches
              .filter((b) => !b.isArchived)
              .map((batch) => (
                <SelectItem key={batch.id} value={batch.id}>
                  {batch.name}
                </SelectItem>
              ))}
          </SelectContent>
        </Select>

        {selectedBatchId && groups.length > 0 && (
          <Select value={selectedGroupId} onValueChange={setSelectedGroupId}>
            <SelectTrigger className="w-[200px]">
              <SelectValue placeholder="All Groups" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="">All Groups</SelectItem>
              {groups.map((group) => (
                <SelectItem key={group.id} value={group.id}>
                  {group.name}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        )}
      </div>

      {!selectedBatchId ? (
        <Card>
          <CardContent className="flex flex-col items-center justify-center py-12">
            <Users className="size-12 text-muted-foreground mb-4" />
            <h3 className="text-lg font-medium mb-2">Select a Batch</h3>
            <p className="text-muted-foreground text-center">
              Choose a batch to view attendance reports.
            </p>
          </CardContent>
        </Card>
      ) : !summary || summary.length === 0 ? (
        <Card>
          <CardContent className="flex flex-col items-center justify-center py-12">
            <Users className="size-12 text-muted-foreground mb-4" />
            <h3 className="text-lg font-medium mb-2">No Data Available</h3>
            <p className="text-muted-foreground text-center">
              No attendance records found for the selected period.
            </p>
          </CardContent>
        </Card>
      ) : (
        <>
          {/* Summary Stats */}
          <div className="grid gap-4 sm:grid-cols-4">
            <Card>
              <CardContent className="pt-4">
                <div className="text-center">
                  <p className="text-3xl font-bold">{summary.length}</p>
                  <p className="text-sm text-muted-foreground">Total Students</p>
                </div>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="pt-4">
                <div className="text-center">
                  <p className="text-3xl font-bold text-success">
                    {Math.round(
                      summary.reduce((acc, s) => acc + s.percentage, 0) /
                        summary.length
                    )}
                    %
                  </p>
                  <p className="text-sm text-muted-foreground">Avg Attendance</p>
                </div>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="pt-4">
                <div className="text-center">
                  <p className="text-3xl font-bold">
                    {summary.filter((s) => s.percentage >= 75).length}
                  </p>
                  <p className="text-sm text-muted-foreground">Above 75%</p>
                </div>
              </CardContent>
            </Card>
            <Card>
              <CardContent className="pt-4">
                <div className="text-center">
                  <p className="text-3xl font-bold text-destructive">
                    {summary.filter((s) => s.percentage < 75).length}
                  </p>
                  <p className="text-sm text-muted-foreground">Below 75%</p>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Detailed Report */}
          <Card>
            <CardHeader>
              <CardTitle>
                Attendance Report - {format(monthDate, 'MMMM yyyy')}
              </CardTitle>
              <CardDescription>
                Working days: {daysInMonth.length}
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="overflow-x-auto">
                <table className="w-full text-sm">
                  <thead>
                    <tr className="border-b">
                      <th className="text-left p-2 font-medium sticky left-0 bg-background">
                        Student
                      </th>
                      <th className="text-center p-2 font-medium">P</th>
                      <th className="text-center p-2 font-medium">A</th>
                      <th className="text-center p-2 font-medium">L</th>
                      <th className="text-center p-2 font-medium">%</th>
                    </tr>
                  </thead>
                  <tbody>
                    {summary
                      .sort((a, b) => b.percentage - a.percentage)
                      .map((record) => (
                        <tr key={record.studentId} className="border-b">
                          <td className="p-2 sticky left-0 bg-background">
                            <div className="flex items-center gap-2">
                              <Avatar className="size-8">
                                <AvatarImage
                                  src={record.student?.photoUrl}
                                  alt={record.student?.firstName}
                                />
                                <AvatarFallback className="text-xs">
                                  {record.student
                                    ? getInitials(
                                        record.student.firstName,
                                        record.student.lastName
                                      )
                                    : '??'}
                                </AvatarFallback>
                              </Avatar>
                              <span className="font-medium">
                                {record.student
                                  ? `${record.student.firstName} ${record.student.lastName}`
                                  : 'Unknown'}
                              </span>
                            </div>
                          </td>
                          <td className="text-center p-2">
                            <Badge className="bg-success text-success-foreground">
                              {record.presentDays}
                            </Badge>
                          </td>
                          <td className="text-center p-2">
                            <Badge variant="destructive">
                              {record.absentDays}
                            </Badge>
                          </td>
                          <td className="text-center p-2">
                            <Badge className="bg-warning text-warning-foreground">
                              {record.leaveDays}
                            </Badge>
                          </td>
                          <td className="text-center p-2">
                            <span
                              className={cn(
                                'font-medium',
                                record.percentage >= 75
                                  ? 'text-success'
                                  : 'text-destructive'
                              )}
                            >
                              {record.percentage}%
                            </span>
                          </td>
                        </tr>
                      ))}
                  </tbody>
                </table>
              </div>
            </CardContent>
          </Card>
        </>
      )}
    </div>
  )
}
