'use client'

import Link from 'next/link'
import {
  Users,
  CalendarCheck,
  IndianRupee,
  Bell,
  TrendingUp,
  FileText,
  UserPlus,
  CreditCard,
  ClipboardList,
} from 'lucide-react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { Skeleton } from '@/components/ui/skeleton'
import { useDashboardStats } from '@/lib/queries'
import { format } from 'date-fns'

function StatCard({
  title,
  value,
  description,
  icon: Icon,
  trend,
  href,
}: {
  title: string
  value: string | number
  description?: string
  icon: React.ElementType
  trend?: { value: number; positive: boolean }
  href?: string
}) {
  const content = (
    <Card className="hover:shadow-md transition-shadow">
      <CardHeader className="flex flex-row items-center justify-between pb-2">
        <CardTitle className="text-sm font-medium text-muted-foreground">
          {title}
        </CardTitle>
        <Icon className="size-4 text-muted-foreground" />
      </CardHeader>
      <CardContent>
        <div className="text-2xl font-bold">{value}</div>
        {description && (
          <p className="text-xs text-muted-foreground mt-1">{description}</p>
        )}
        {trend && (
          <div className="flex items-center gap-1 mt-2">
            <TrendingUp
              className={`size-3 ${trend.positive ? 'text-success' : 'text-destructive rotate-180'}`}
            />
            <span
              className={`text-xs ${trend.positive ? 'text-success' : 'text-destructive'}`}
            >
              {trend.positive ? '+' : ''}{trend.value}%
            </span>
            <span className="text-xs text-muted-foreground">from last month</span>
          </div>
        )}
      </CardContent>
    </Card>
  )

  if (href) {
    return <Link href={href}>{content}</Link>
  }

  return content
}

function QuickActionButton({
  title,
  icon: Icon,
  href,
}: {
  title: string
  icon: React.ElementType
  href: string
}) {
  return (
    <Button variant="outline" className="h-auto py-4 flex-col gap-2" asChild>
      <Link href={href}>
        <Icon className="size-5" />
        <span className="text-xs">{title}</span>
      </Link>
    </Button>
  )
}

function DashboardSkeleton() {
  return (
    <div className="space-y-6">
      <div>
        <Skeleton className="h-8 w-48 mb-2" />
        <Skeleton className="h-4 w-64" />
      </div>
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        {[1, 2, 3, 4].map((i) => (
          <Skeleton key={i} className="h-32" />
        ))}
      </div>
      <div className="grid gap-6 md:grid-cols-2">
        <Skeleton className="h-64" />
        <Skeleton className="h-64" />
      </div>
    </div>
  )
}

export default function DashboardPage() {
  const { stats, isLoading } = useDashboardStats()

  if (isLoading) {
    return <DashboardSkeleton />
  }

  const attendancePercentage = stats?.todayAttendance?.total
    ? Math.round((stats.todayAttendance.present / stats.todayAttendance.total) * 100)
    : 0

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold tracking-tight">Dashboard</h1>
        <p className="text-muted-foreground">
          Welcome back! Here&apos;s an overview of your academy.
        </p>
      </div>

      {/* Stats Grid */}
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
        <StatCard
          title="Total Students"
          value={stats?.totalStudents ?? 0}
          description={`${stats?.activeStudents ?? 0} active`}
          icon={Users}
          href="/students"
        />
        <StatCard
          title="Today's Attendance"
          value={`${attendancePercentage}%`}
          description={`${stats?.todayAttendance?.present ?? 0} of ${stats?.todayAttendance?.total ?? 0} present`}
          icon={CalendarCheck}
          href="/attendance"
        />
        <StatCard
          title="Today's Collection"
          value={`₹${(stats?.todayFeeCollection ?? 0).toLocaleString('en-IN')}`}
          icon={IndianRupee}
          href="/fees"
        />
        <StatCard
          title="Pending Alerts"
          value={stats?.pendingAlerts ?? 0}
          description="Messages awaiting approval"
          icon={Bell}
          href="/whatsapp"
        />
      </div>

      {/* Quick Actions */}
      <Card>
        <CardHeader>
          <CardTitle>Quick Actions</CardTitle>
          <CardDescription>Common tasks you perform frequently</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            <QuickActionButton
              title="Add Student"
              icon={UserPlus}
              href="/students/new"
            />
            <QuickActionButton
              title="Mark Attendance"
              icon={ClipboardList}
              href="/attendance"
            />
            <QuickActionButton
              title="Collect Fee"
              icon={CreditCard}
              href="/fees/collect"
            />
            <QuickActionButton
              title="New Exam"
              icon={FileText}
              href="/exams/new"
            />
          </div>
        </CardContent>
      </Card>

      <div className="grid gap-6 md:grid-cols-2">
        {/* Today's Attendance Summary */}
        <Card>
          <CardHeader>
            <CardTitle>Today&apos;s Attendance</CardTitle>
            <CardDescription>{format(new Date(), 'EEEE, MMMM d, yyyy')}</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <div className="size-3 rounded-full bg-success" />
                  <span className="text-sm">Present</span>
                </div>
                <span className="font-medium">
                  {stats?.todayAttendance?.present ?? 0}
                </span>
              </div>
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <div className="size-3 rounded-full bg-destructive" />
                  <span className="text-sm">Absent</span>
                </div>
                <span className="font-medium">
                  {stats?.todayAttendance?.absent ?? 0}
                </span>
              </div>
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <div className="size-3 rounded-full bg-warning" />
                  <span className="text-sm">On Leave</span>
                </div>
                <span className="font-medium">
                  {stats?.todayAttendance?.leave ?? 0}
                </span>
              </div>
              <div className="pt-4 border-t">
                <div className="flex items-center justify-between text-sm text-muted-foreground mb-2">
                  <span>Attendance Rate</span>
                  <span>{attendancePercentage}%</span>
                </div>
                <div className="h-2 bg-muted rounded-full overflow-hidden">
                  <div
                    className="h-full bg-success transition-all duration-500"
                    style={{ width: `${attendancePercentage}%` }}
                  />
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Upcoming Exams */}
        <Card>
          <CardHeader className="flex flex-row items-center justify-between">
            <div>
              <CardTitle>Upcoming Exams</CardTitle>
              <CardDescription>Scheduled exams this month</CardDescription>
            </div>
            <Button variant="outline" size="sm" asChild>
              <Link href="/exams">View All</Link>
            </Button>
          </CardHeader>
          <CardContent>
            {stats?.upcomingExams && stats.upcomingExams.length > 0 ? (
              <div className="space-y-4">
                {stats.upcomingExams.slice(0, 4).map((exam) => (
                  <div
                    key={exam.id}
                    className="flex items-center justify-between"
                  >
                    <div>
                      <p className="font-medium">{exam.name}</p>
                      <p className="text-sm text-muted-foreground">
                        {exam.subject} - {exam.batch?.name}
                      </p>
                    </div>
                    <div className="text-right">
                      <Badge variant="outline">
                        {format(new Date(exam.examDate), 'MMM d')}
                      </Badge>
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <div className="text-center py-8 text-muted-foreground">
                <FileText className="size-8 mx-auto mb-2 opacity-50" />
                <p>No upcoming exams</p>
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      {/* Recent Activity */}
      <Card>
        <CardHeader>
          <CardTitle>Recent Activity</CardTitle>
          <CardDescription>Latest actions in the system</CardDescription>
        </CardHeader>
        <CardContent>
          {stats?.recentActivity && stats.recentActivity.length > 0 ? (
            <div className="space-y-4">
              {stats.recentActivity.map((activity) => (
                <div
                  key={activity.id}
                  className="flex items-center gap-4 text-sm"
                >
                  <div className="size-2 rounded-full bg-primary" />
                  <p className="flex-1">{activity.description}</p>
                  <span className="text-muted-foreground">
                    {format(new Date(activity.timestamp), 'h:mm a')}
                  </span>
                </div>
              ))}
            </div>
          ) : (
            <div className="text-center py-8 text-muted-foreground">
              <p>No recent activity</p>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  )
}
