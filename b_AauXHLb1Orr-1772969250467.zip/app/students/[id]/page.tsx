'use client'

import { use, useState } from 'react'
import Link from 'next/link'
import { useRouter } from 'next/navigation'
import { format } from 'date-fns'
import {
  ArrowLeft,
  Pencil,
  Phone,
  Mail,
  MapPin,
  Calendar,
  IndianRupee,
  GraduationCap,
  Users,
  MessageCircle,
  FileText,
  CalendarCheck,
} from 'lucide-react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { Skeleton } from '@/components/ui/skeleton'
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { Separator } from '@/components/ui/separator'
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table'
import {
  useStudent,
  useStudentAttendance,
  useStudentFees,
  useStudentMessages,
} from '@/lib/queries'
import type { AttendanceStatus, FeeStatus } from '@/lib/types'

function ProfileSkeleton() {
  return (
    <div className="space-y-6">
      <div className="flex items-center gap-4">
        <Skeleton className="size-10" />
        <div>
          <Skeleton className="h-8 w-48 mb-2" />
          <Skeleton className="h-4 w-32" />
        </div>
      </div>
      <div className="grid gap-6 lg:grid-cols-3">
        <Skeleton className="h-64" />
        <Skeleton className="h-64 lg:col-span-2" />
      </div>
    </div>
  )
}

function getInitials(firstName: string, lastName: string) {
  return `${firstName.charAt(0)}${lastName.charAt(0)}`.toUpperCase()
}

function getStatusBadge(status: AttendanceStatus) {
  switch (status) {
    case 'present':
      return <Badge className="bg-success text-success-foreground">Present</Badge>
    case 'absent':
      return <Badge variant="destructive">Absent</Badge>
    case 'leave':
      return <Badge className="bg-warning text-warning-foreground">Leave</Badge>
  }
}

function getFeeStatusBadge(status: FeeStatus) {
  switch (status) {
    case 'paid':
      return <Badge className="bg-success text-success-foreground">Paid</Badge>
    case 'partial':
      return <Badge className="bg-warning text-warning-foreground">Partial</Badge>
    case 'pending':
      return <Badge variant="secondary">Pending</Badge>
    case 'overdue':
      return <Badge variant="destructive">Overdue</Badge>
  }
}

export default function StudentProfilePage({
  params,
}: {
  params: Promise<{ id: string }>
}) {
  const { id } = use(params)
  const router = useRouter()
  const { student, isLoading } = useStudent(id)
  const { records: attendanceRecords } = useStudentAttendance(id)
  const { fees } = useStudentFees(id)
  const { messages } = useStudentMessages(id)
  const [activeTab, setActiveTab] = useState('overview')

  if (isLoading) {
    return <ProfileSkeleton />
  }

  if (!student) {
    return (
      <div className="flex flex-col items-center justify-center py-12">
        <h2 className="text-lg font-medium mb-2">Student not found</h2>
        <p className="text-muted-foreground mb-4">
          The student you&apos;re looking for doesn&apos;t exist.
        </p>
        <Button asChild>
          <Link href="/students">Back to Students</Link>
        </Button>
      </div>
    )
  }

  // Calculate attendance stats
  const totalAttendance = attendanceRecords.length
  const presentDays = attendanceRecords.filter((r) => r.status === 'present').length
  const attendancePercentage = totalAttendance > 0
    ? Math.round((presentDays / totalAttendance) * 100)
    : 0

  // Calculate fee stats
  const totalFees = fees.reduce((sum, f) => sum + f.amount, 0)
  const paidFees = fees.reduce((sum, f) => sum + f.paidAmount, 0)
  const outstandingFees = totalFees - paidFees

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-4">
          <Button variant="ghost" size="icon" onClick={() => router.back()}>
            <ArrowLeft className="size-4" />
          </Button>
          <div>
            <h1 className="text-2xl font-bold tracking-tight">
              {student.firstName} {student.lastName}
            </h1>
            <p className="text-muted-foreground">
              {student.batch?.name ?? 'No batch'} - {student.enrollmentId}
            </p>
          </div>
        </div>
        <Button asChild>
          <Link href={`/students/${student.id}/edit`}>
            <Pencil className="mr-2 size-4" />
            Edit Profile
          </Link>
        </Button>
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab}>
        <TabsList>
          <TabsTrigger value="overview">Overview</TabsTrigger>
          <TabsTrigger value="attendance">Attendance</TabsTrigger>
          <TabsTrigger value="fees">Fees</TabsTrigger>
          <TabsTrigger value="exams">Exams</TabsTrigger>
          <TabsTrigger value="whatsapp">WhatsApp</TabsTrigger>
        </TabsList>

        {/* Overview Tab */}
        <TabsContent value="overview" className="space-y-6">
          <div className="grid gap-6 lg:grid-cols-3">
            {/* Profile Card */}
            <Card>
              <CardContent className="pt-6">
                <div className="flex flex-col items-center text-center">
                  <Avatar className="size-24 mb-4">
                    <AvatarImage src={student.photoUrl} alt={student.firstName} />
                    <AvatarFallback className="text-2xl">
                      {getInitials(student.firstName, student.lastName)}
                    </AvatarFallback>
                  </Avatar>
                  <h2 className="text-xl font-semibold">
                    {student.firstName} {student.lastName}
                  </h2>
                  <p className="text-muted-foreground">{student.enrollmentId}</p>
                  <Badge
                    className={`mt-2 ${student.isActive ? 'bg-success text-success-foreground' : ''}`}
                    variant={student.isActive ? 'default' : 'secondary'}
                  >
                    {student.isActive ? 'Active' : 'Inactive'}
                  </Badge>
                </div>
                <Separator className="my-6" />
                <div className="space-y-3">
                  <div className="flex items-center gap-3 text-sm">
                    <Calendar className="size-4 text-muted-foreground" />
                    <span>
                      Born {format(new Date(student.dateOfBirth), 'MMM d, yyyy')}
                    </span>
                  </div>
                  <div className="flex items-center gap-3 text-sm">
                    <GraduationCap className="size-4 text-muted-foreground" />
                    <span>{student.batch?.name ?? 'No batch'}</span>
                  </div>
                  {student.group && (
                    <div className="flex items-center gap-3 text-sm">
                      <Users className="size-4 text-muted-foreground" />
                      <span>{student.group.name}</span>
                    </div>
                  )}
                  <div className="flex items-center gap-3 text-sm">
                    <Calendar className="size-4 text-muted-foreground" />
                    <span>
                      Joined {format(new Date(student.joiningDate), 'MMM d, yyyy')}
                    </span>
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Contact & Stats */}
            <div className="lg:col-span-2 space-y-6">
              {/* Parent Contact */}
              <Card>
                <CardHeader>
                  <CardTitle>Parent / Guardian</CardTitle>
                </CardHeader>
                <CardContent className="grid gap-4 sm:grid-cols-2">
                  <div>
                    <p className="text-sm text-muted-foreground">Name</p>
                    <p className="font-medium">{student.parentName}</p>
                  </div>
                  <div>
                    <p className="text-sm text-muted-foreground">Phone</p>
                    <p className="font-medium flex items-center gap-2">
                      <Phone className="size-4" />
                      {student.parentPhone}
                    </p>
                  </div>
                  {student.parentEmail && (
                    <div>
                      <p className="text-sm text-muted-foreground">Email</p>
                      <p className="font-medium flex items-center gap-2">
                        <Mail className="size-4" />
                        {student.parentEmail}
                      </p>
                    </div>
                  )}
                  {student.address && (
                    <div className="sm:col-span-2">
                      <p className="text-sm text-muted-foreground">Address</p>
                      <p className="font-medium flex items-start gap-2">
                        <MapPin className="size-4 mt-0.5" />
                        {student.address}
                      </p>
                    </div>
                  )}
                </CardContent>
              </Card>

              {/* Quick Stats */}
              <div className="grid gap-4 sm:grid-cols-3">
                <Card>
                  <CardContent className="pt-6">
                    <div className="flex items-center gap-4">
                      <div className="flex size-10 items-center justify-center rounded-full bg-success/10">
                        <CalendarCheck className="size-5 text-success" />
                      </div>
                      <div>
                        <p className="text-2xl font-bold">{attendancePercentage}%</p>
                        <p className="text-sm text-muted-foreground">Attendance</p>
                      </div>
                    </div>
                  </CardContent>
                </Card>
                <Card>
                  <CardContent className="pt-6">
                    <div className="flex items-center gap-4">
                      <div className="flex size-10 items-center justify-center rounded-full bg-primary/10">
                        <IndianRupee className="size-5 text-primary" />
                      </div>
                      <div>
                        <p className="text-2xl font-bold">
                          ₹{outstandingFees.toLocaleString('en-IN')}
                        </p>
                        <p className="text-sm text-muted-foreground">Outstanding</p>
                      </div>
                    </div>
                  </CardContent>
                </Card>
                <Card>
                  <CardContent className="pt-6">
                    <div className="flex items-center gap-4">
                      <div className="flex size-10 items-center justify-center rounded-full bg-info/10">
                        <MessageCircle className="size-5 text-info" />
                      </div>
                      <div>
                        <p className="text-2xl font-bold">{messages.length}</p>
                        <p className="text-sm text-muted-foreground">Messages</p>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              </div>
            </div>
          </div>
        </TabsContent>

        {/* Attendance Tab */}
        <TabsContent value="attendance" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Attendance History</CardTitle>
              <CardDescription>
                {presentDays} of {totalAttendance} days present ({attendancePercentage}%)
              </CardDescription>
            </CardHeader>
            <CardContent>
              {attendanceRecords.length > 0 ? (
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Date</TableHead>
                      <TableHead>Day</TableHead>
                      <TableHead>Status</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {attendanceRecords.slice(0, 20).map((record) => (
                      <TableRow key={record.id}>
                        <TableCell>
                          {format(new Date(record.date), 'MMM d, yyyy')}
                        </TableCell>
                        <TableCell>
                          {format(new Date(record.date), 'EEEE')}
                        </TableCell>
                        <TableCell>{getStatusBadge(record.status)}</TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              ) : (
                <div className="text-center py-8 text-muted-foreground">
                  <CalendarCheck className="size-8 mx-auto mb-2 opacity-50" />
                  <p>No attendance records yet</p>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        {/* Fees Tab */}
        <TabsContent value="fees" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Fee History</CardTitle>
              <CardDescription>
                Total: ₹{totalFees.toLocaleString('en-IN')} | Paid: ₹
                {paidFees.toLocaleString('en-IN')} | Outstanding: ₹
                {outstandingFees.toLocaleString('en-IN')}
              </CardDescription>
            </CardHeader>
            <CardContent>
              {fees.length > 0 ? (
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Month</TableHead>
                      <TableHead>Amount</TableHead>
                      <TableHead>Paid</TableHead>
                      <TableHead>Status</TableHead>
                      <TableHead>Receipt</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {fees.map((fee) => (
                      <TableRow key={fee.id}>
                        <TableCell>
                          {format(new Date(fee.month + '-01'), 'MMMM yyyy')}
                        </TableCell>
                        <TableCell>
                          ₹{fee.amount.toLocaleString('en-IN')}
                        </TableCell>
                        <TableCell>
                          ₹{fee.paidAmount.toLocaleString('en-IN')}
                        </TableCell>
                        <TableCell>{getFeeStatusBadge(fee.status)}</TableCell>
                        <TableCell>
                          {fee.receiptNumber ? (
                            <Button variant="link" size="sm" className="h-auto p-0">
                              {fee.receiptNumber}
                            </Button>
                          ) : (
                            '-'
                          )}
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              ) : (
                <div className="text-center py-8 text-muted-foreground">
                  <IndianRupee className="size-8 mx-auto mb-2 opacity-50" />
                  <p>No fee records yet</p>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        {/* Exams Tab */}
        <TabsContent value="exams" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Exam Results</CardTitle>
              <CardDescription>Performance in exams</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="text-center py-8 text-muted-foreground">
                <FileText className="size-8 mx-auto mb-2 opacity-50" />
                <p>No exam results yet</p>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* WhatsApp Tab */}
        <TabsContent value="whatsapp" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Message History</CardTitle>
              <CardDescription>
                WhatsApp messages sent to parent/guardian
              </CardDescription>
            </CardHeader>
            <CardContent>
              {messages.length > 0 ? (
                <div className="space-y-4">
                  {messages.map((message) => (
                    <div
                      key={message.id}
                      className="flex items-start gap-4 p-4 rounded-lg border"
                    >
                      <MessageCircle className="size-5 text-muted-foreground mt-0.5" />
                      <div className="flex-1">
                        <div className="flex items-center justify-between mb-1">
                          <Badge variant="outline">{message.messageType}</Badge>
                          <span className="text-xs text-muted-foreground">
                            {format(new Date(message.createdAt), 'MMM d, yyyy h:mm a')}
                          </span>
                        </div>
                        <p className="text-sm">{message.content}</p>
                        {message.status === 'failed' && (
                          <p className="text-xs text-destructive mt-1">
                            Failed: {message.error}
                          </p>
                        )}
                      </div>
                      <Badge
                        variant={
                          message.status === 'sent'
                            ? 'default'
                            : message.status === 'failed'
                              ? 'destructive'
                              : 'secondary'
                        }
                        className={message.status === 'sent' ? 'bg-success text-success-foreground' : ''}
                      >
                        {message.status}
                      </Badge>
                    </div>
                  ))}
                </div>
              ) : (
                <div className="text-center py-8 text-muted-foreground">
                  <MessageCircle className="size-8 mx-auto mb-2 opacity-50" />
                  <p>No messages sent yet</p>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}
