import { StudentForm } from '@/components/students/student-form'

export default function NewStudentPage() {
  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold tracking-tight">Add New Student</h1>
        <p className="text-muted-foreground">
          Fill in the details to register a new student
        </p>
      </div>
      <StudentForm mode="create" />
    </div>
  )
}
