'use client'

import { useState } from 'react'
import Link from 'next/link'
import { format } from 'date-fns'
import {
  IndianRupee,
  Search,
  Filter,
  CreditCard,
  AlertCircle,
  CheckCircle,
  Clock,
  Users,
} from 'lucide-react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { Skeleton } from '@/components/ui/skeleton'
import { Input } from '@/components/ui/input'
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar'
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select'
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table'
import { useBatches, useFees, useFeeSummary } from '@/lib/queries'
import type { FeeStatus, FeeFilters } from '@/lib/types'

function FeesSkeleton() {
  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <Skeleton className="h-8 w-32 mb-2" />
          <Skeleton className="h-4 w-48" />
        </div>
        <Skeleton className="h-10 w-36" />
      </div>
      <div className="grid gap-4 md:grid-cols-4">
        {[1, 2, 3, 4].map((i) => (
          <Skeleton key={i} className="h-24" />
        ))}
      </div>
      <Skeleton className="h-96" />
    </div>
  )
}

function getInitials(firstName: string, lastName: string) {
  return `${firstName.charAt(0)}${lastName.charAt(0)}`.toUpperCase()
}

function getFeeStatusBadge(status: FeeStatus) {
  switch (status) {
    case 'paid':
      return (
        <Badge className="bg-success text-success-foreground">
          <CheckCircle className="mr-1 size-3" />
          Paid
        </Badge>
      )
    case 'partial':
      return (
        <Badge className="bg-warning text-warning-foreground">
          <Clock className="mr-1 size-3" />
          Partial
        </Badge>
      )
    case 'pending':
      return (
        <Badge variant="secondary">
          <Clock className="mr-1 size-3" />
          Pending
        </Badge>
      )
    case 'overdue':
      return (
        <Badge variant="destructive">
          <AlertCircle className="mr-1 size-3" />
          Overdue
        </Badge>
      )
  }
}

// Generate month options for the last 12 months
function getMonthOptions() {
  const options = []
  const today = new Date()
  for (let i = 0; i < 12; i++) {
    const date = new Date(today.getFullYear(), today.getMonth() - i, 1)
    options.push({
      value: format(date, 'yyyy-MM'),
      label: format(date, 'MMMM yyyy'),
    })
  }
  return options
}

export default function FeesPage() {
  const [searchQuery, setSearchQuery] = useState('')
  const [filters, setFilters] = useState<FeeFilters>({
    month: format(new Date(), 'yyyy-MM'),
  })

  const { batches, isLoading: batchesLoading } = useBatches()
  const { fees, isLoading: feesLoading, refresh } = useFees(filters)
  const { summary, isLoading: summaryLoading } = useFeeSummary(filters.month)

  const monthOptions = getMonthOptions()

  // Filter fees by search query
  const filteredFees = fees.filter((fee) => {
    if (!searchQuery) return true
    const query = searchQuery.toLowerCase()
    return (
      fee.student?.firstName?.toLowerCase().includes(query) ||
      fee.student?.lastName?.toLowerCase().includes(query) ||
      fee.student?.enrollmentId?.toLowerCase().includes(query)
    )
  })

  const isLoading = batchesLoading || feesLoading || summaryLoading

  if (isLoading && fees.length === 0) {
    return <FeesSkeleton />
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold tracking-tight">Fee Management</h1>
          <p className="text-muted-foreground">
            Track and collect student fees
          </p>
        </div>
        <Button asChild>
          <Link href="/fees/collect">
            <CreditCard className="mr-2 size-4" />
            Collect Fee
          </Link>
        </Button>
      </div>

      {/* Summary Stats */}
      <div className="grid gap-4 md:grid-cols-4">
        <Card>
          <CardContent className="pt-4">
            <div className="flex items-center gap-4">
              <div className="flex size-10 items-center justify-center rounded-full bg-primary/10">
                <IndianRupee className="size-5 text-primary" />
              </div>
              <div>
                <p className="text-2xl font-bold">
                  ₹{(summary?.totalExpected ?? 0).toLocaleString('en-IN')}
                </p>
                <p className="text-sm text-muted-foreground">Expected</p>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-4">
            <div className="flex items-center gap-4">
              <div className="flex size-10 items-center justify-center rounded-full bg-success/10">
                <CheckCircle className="size-5 text-success" />
              </div>
              <div>
                <p className="text-2xl font-bold text-success">
                  ₹{(summary?.totalCollected ?? 0).toLocaleString('en-IN')}
                </p>
                <p className="text-sm text-muted-foreground">Collected</p>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-4">
            <div className="flex items-center gap-4">
              <div className="flex size-10 items-center justify-center rounded-full bg-destructive/10">
                <AlertCircle className="size-5 text-destructive" />
              </div>
              <div>
                <p className="text-2xl font-bold text-destructive">
                  ₹{(summary?.totalPending ?? 0).toLocaleString('en-IN')}
                </p>
                <p className="text-sm text-muted-foreground">Pending</p>
              </div>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-4">
            <div className="flex items-center gap-4">
              <div className="flex size-10 items-center justify-center rounded-full bg-warning/10">
                <Clock className="size-5 text-warning" />
              </div>
              <div>
                <p className="text-2xl font-bold">
                  {summary?.overdueCount ?? 0}
                </p>
                <p className="text-sm text-muted-foreground">Overdue</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Filters */}
      <div className="flex flex-col gap-4 sm:flex-row">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 size-4 -translate-y-1/2 text-muted-foreground" />
          <Input
            placeholder="Search by student name or ID..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="pl-9"
          />
        </div>
        <Select
          value={filters.month}
          onValueChange={(value) => setFilters({ ...filters, month: value })}
        >
          <SelectTrigger className="w-full sm:w-[200px]">
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            {monthOptions.map((option) => (
              <SelectItem key={option.value} value={option.value}>
                {option.label}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>
        <Select
          value={filters.batchId ?? ''}
          onValueChange={(value) =>
            setFilters({ ...filters, batchId: value || undefined })
          }
        >
          <SelectTrigger className="w-full sm:w-[180px]">
            <SelectValue placeholder="All Batches" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="">All Batches</SelectItem>
            {batches
              .filter((b) => !b.isArchived)
              .map((batch) => (
                <SelectItem key={batch.id} value={batch.id}>
                  {batch.name}
                </SelectItem>
              ))}
          </SelectContent>
        </Select>
        <Select
          value={filters.status ?? ''}
          onValueChange={(value) =>
            setFilters({
              ...filters,
              status: (value as FeeStatus) || undefined,
            })
          }
        >
          <SelectTrigger className="w-full sm:w-[140px]">
            <SelectValue placeholder="All Status" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="">All Status</SelectItem>
            <SelectItem value="paid">Paid</SelectItem>
            <SelectItem value="partial">Partial</SelectItem>
            <SelectItem value="pending">Pending</SelectItem>
            <SelectItem value="overdue">Overdue</SelectItem>
          </SelectContent>
        </Select>
      </div>

      {/* Fee Records Table */}
      {filteredFees.length === 0 ? (
        <Card>
          <CardContent className="flex flex-col items-center justify-center py-12">
            <IndianRupee className="size-12 text-muted-foreground mb-4" />
            <h3 className="text-lg font-medium mb-2">No fee records</h3>
            <p className="text-muted-foreground text-center mb-4">
              {searchQuery || filters.batchId || filters.status
                ? 'Try adjusting your search or filters.'
                : 'No fee records found for this month.'}
            </p>
          </CardContent>
        </Card>
      ) : (
        <Card>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead className="w-12"></TableHead>
                <TableHead>Student</TableHead>
                <TableHead>Batch</TableHead>
                <TableHead>Amount</TableHead>
                <TableHead>Paid</TableHead>
                <TableHead>Balance</TableHead>
                <TableHead>Status</TableHead>
                <TableHead>Action</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {filteredFees.map((fee) => {
                const balance = fee.amount - fee.paidAmount
                return (
                  <TableRow key={fee.id}>
                    <TableCell>
                      <Avatar className="size-10">
                        <AvatarImage
                          src={fee.student?.photoUrl}
                          alt={fee.student?.firstName}
                        />
                        <AvatarFallback>
                          {fee.student
                            ? getInitials(
                                fee.student.firstName,
                                fee.student.lastName
                              )
                            : '??'}
                        </AvatarFallback>
                      </Avatar>
                    </TableCell>
                    <TableCell>
                      <div>
                        <p className="font-medium">
                          {fee.student
                            ? `${fee.student.firstName} ${fee.student.lastName}`
                            : 'Unknown'}
                        </p>
                        <p className="text-sm text-muted-foreground">
                          {fee.student?.enrollmentId}
                        </p>
                      </div>
                    </TableCell>
                    <TableCell>
                      <span className="text-sm">
                        {fee.student?.batch?.name ?? '-'}
                      </span>
                    </TableCell>
                    <TableCell>
                      <span className="font-medium">
                        ₹{fee.amount.toLocaleString('en-IN')}
                      </span>
                    </TableCell>
                    <TableCell>
                      <span className="text-success">
                        ₹{fee.paidAmount.toLocaleString('en-IN')}
                      </span>
                    </TableCell>
                    <TableCell>
                      <span
                        className={
                          balance > 0 ? 'text-destructive font-medium' : ''
                        }
                      >
                        ₹{balance.toLocaleString('en-IN')}
                      </span>
                    </TableCell>
                    <TableCell>{getFeeStatusBadge(fee.status)}</TableCell>
                    <TableCell>
                      {fee.status !== 'paid' && (
                        <Button variant="outline" size="sm" asChild>
                          <Link
                            href={`/fees/collect?studentId=${fee.studentId}&month=${fee.month}`}
                          >
                            <CreditCard className="mr-1 size-3" />
                            Collect
                          </Link>
                        </Button>
                      )}
                    </TableCell>
                  </TableRow>
                )
              })}
            </TableBody>
          </Table>
        </Card>
      )}

      {/* Summary */}
      <div className="flex items-center justify-between text-sm text-muted-foreground">
        <span>
          Showing {filteredFees.length} of {fees.length} records
        </span>
      </div>
    </div>
  )
}
