'use client'

import { useState } from 'react'
import { Download, Eye, MoreHorizontal, Search, Filter, Printer } from 'lucide-react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Badge } from '@/components/ui/badge'
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table'
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu'
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from '@/components/ui/dialog'
import { useFeeReceipts } from '@/lib/queries'
import { format } from 'date-fns'

export default function ReceiptsPage() {
  const { receipts, isLoading } = useFeeReceipts()
  const [search, setSearch] = useState('')
  const [selectedReceipt, setSelectedReceipt] = useState<any>(null)
  const [showPreview, setShowPreview] = useState(false)

  const filteredReceipts = receipts?.filter(
    (receipt) =>
      receipt.student.name.toLowerCase().includes(search.toLowerCase()) ||
      receipt.receiptNumber.toLowerCase().includes(search.toLowerCase())
  ) || []

  const handlePrint = (receipt: any) => {
    const printContent = `
      <div style="font-family: Arial, sans-serif; padding: 20px; max-width: 600px; margin: 0 auto;">
        <div style="text-align: center; margin-bottom: 30px;">
          <h1>TIPS Academy</h1>
          <h2>FEE RECEIPT</h2>
          <hr />
        </div>
        
        <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 20px; margin-bottom: 20px;">
          <div>
            <p><strong>Receipt No:</strong> ${receipt.receiptNumber}</p>
            <p><strong>Date:</strong> ${format(new Date(receipt.receivedDate), 'dd/MM/yyyy')}</p>
          </div>
          <div style="text-align: right;">
            <p><strong>Student:</strong> ${receipt.student.name}</p>
            <p><strong>Enrollment ID:</strong> ${receipt.student.enrollmentId}</p>
          </div>
        </div>
        
        <table style="width: 100%; border-collapse: collapse; margin-bottom: 20px;">
          <tr style="border-bottom: 2px solid #000;">
            <td style="padding: 10px; font-weight: bold;">Amount</td>
            <td style="padding: 10px; font-weight: bold;">Payment Method</td>
            <td style="padding: 10px; font-weight: bold; text-align: right;">Total</td>
          </tr>
          <tr style="border-bottom: 1px solid #ccc;">
            <td style="padding: 10px;">₹${receipt.amount}</td>
            <td style="padding: 10px;">${receipt.paymentMethod}</td>
            <td style="padding: 10px; text-align: right;"><strong>₹${receipt.amount}</strong></td>
          </tr>
        </table>
        
        ${receipt.notes ? `<p><strong>Notes:</strong> ${receipt.notes}</p>` : ''}
        
        <div style="margin-top: 40px; padding-top: 20px; border-top: 1px solid #ccc;">
          <p>Thank you for your payment!</p>
          <p style="font-size: 12px; color: #666;">This receipt is valid proof of payment.</p>
        </div>
      </div>
    `

    const printWindow = window.open('', '', 'width=800,height=600')
    if (printWindow) {
      printWindow.document.write(printContent)
      printWindow.document.close()
      printWindow.print()
    }
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
        <div>
          <h1 className="text-2xl font-bold tracking-tight">Fee Receipts</h1>
          <p className="text-muted-foreground">View and manage fee payment receipts</p>
        </div>
      </div>

      <Card>
        <CardHeader>
          <div className="flex gap-4">
            <div className="flex-1 relative">
              <Search className="absolute left-3 top-3 size-4 text-muted-foreground" />
              <Input
                placeholder="Search by receipt number or student name"
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                className="pl-10"
              />
            </div>
            <Button variant="outline" size="icon">
              <Filter className="size-4" />
            </Button>
          </div>
        </CardHeader>
        <CardContent>
          <div className="overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Receipt No</TableHead>
                  <TableHead>Student</TableHead>
                  <TableHead>Amount</TableHead>
                  <TableHead>Method</TableHead>
                  <TableHead>Date</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead className="text-center">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {isLoading ? (
                  <TableRow>
                    <TableCell colSpan={7} className="text-center py-8 text-muted-foreground">
                      Loading receipts...
                    </TableCell>
                  </TableRow>
                ) : filteredReceipts.length === 0 ? (
                  <TableRow>
                    <TableCell colSpan={7} className="text-center py-8 text-muted-foreground">
                      No receipts found
                    </TableCell>
                  </TableRow>
                ) : (
                  filteredReceipts.map((receipt) => (
                    <TableRow key={receipt.id}>
                      <TableCell className="font-mono">{receipt.receiptNumber}</TableCell>
                      <TableCell>
                        <div className="flex flex-col">
                          <span className="font-medium">{receipt.student.name}</span>
                          <span className="text-sm text-muted-foreground">{receipt.student.enrollmentId}</span>
                        </div>
                      </TableCell>
                      <TableCell className="font-medium">₹{receipt.amount.toLocaleString('en-IN')}</TableCell>
                      <TableCell className="capitalize">{receipt.paymentMethod}</TableCell>
                      <TableCell>{format(new Date(receipt.receivedDate), 'MMM d, yyyy')}</TableCell>
                      <TableCell>
                        <Badge variant="outline">Received</Badge>
                      </TableCell>
                      <TableCell className="text-center">
                        <DropdownMenu>
                          <DropdownMenuTrigger asChild>
                            <Button variant="ghost" size="sm">
                              <MoreHorizontal className="size-4" />
                            </Button>
                          </DropdownMenuTrigger>
                          <DropdownMenuContent align="end">
                            <DropdownMenuItem
                              onClick={() => {
                                setSelectedReceipt(receipt)
                                setShowPreview(true)
                              }}
                            >
                              <Eye className="mr-2 size-4" />
                              Preview
                            </DropdownMenuItem>
                            <DropdownMenuItem onClick={() => handlePrint(receipt)}>
                              <Printer className="mr-2 size-4" />
                              Print
                            </DropdownMenuItem>
                            <DropdownMenuItem onClick={() => {}}>
                              <Download className="mr-2 size-4" />
                              Download
                            </DropdownMenuItem>
                          </DropdownMenuContent>
                        </DropdownMenu>
                      </TableCell>
                    </TableRow>
                  ))
                )}
              </TableBody>
            </Table>
          </div>
        </CardContent>
      </Card>

      {/* Receipt Preview Dialog */}
      {selectedReceipt && (
        <Dialog open={showPreview} onOpenChange={setShowPreview}>
          <DialogContent className="max-w-2xl">
            <DialogHeader>
              <DialogTitle>Receipt Preview</DialogTitle>
              <DialogDescription>Receipt #{selectedReceipt.receiptNumber}</DialogDescription>
            </DialogHeader>
            <div className="bg-white p-8 rounded-lg border">
              <div className="text-center mb-6">
                <h2 className="text-2xl font-bold">TIPS Academy</h2>
                <h3 className="text-lg font-semibold text-muted-foreground">FEE RECEIPT</h3>
              </div>

              <div className="grid grid-cols-2 gap-4 mb-6">
                <div>
                  <p className="text-sm text-muted-foreground">Receipt No</p>
                  <p className="font-mono font-bold">{selectedReceipt.receiptNumber}</p>
                </div>
                <div className="text-right">
                  <p className="text-sm text-muted-foreground">Date</p>
                  <p className="font-bold">{format(new Date(selectedReceipt.receivedDate), 'dd/MM/yyyy')}</p>
                </div>
              </div>

              <div className="border-t border-b py-4 mb-6">
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <p className="text-sm text-muted-foreground">Student Name</p>
                    <p className="font-bold">{selectedReceipt.student.name}</p>
                    <p className="text-sm text-muted-foreground">ID: {selectedReceipt.student.enrollmentId}</p>
                  </div>
                  <div className="text-right">
                    <p className="text-sm text-muted-foreground">Amount</p>
                    <p className="text-2xl font-bold text-success">₹{selectedReceipt.amount.toLocaleString('en-IN')}</p>
                  </div>
                </div>
              </div>

              <div className="mb-6">
                <p className="text-sm text-muted-foreground">Payment Method</p>
                <p className="capitalize font-medium">{selectedReceipt.paymentMethod}</p>
              </div>

              {selectedReceipt.notes && (
                <div className="mb-6">
                  <p className="text-sm text-muted-foreground">Notes</p>
                  <p className="text-sm">{selectedReceipt.notes}</p>
                </div>
              )}

              <div className="text-center text-sm text-muted-foreground pt-6 border-t">
                <p>Thank you for your payment!</p>
              </div>
            </div>

            <div className="flex gap-3">
              <Button
                variant="outline"
                onClick={() => setShowPreview(false)}
                className="flex-1"
              >
                Close
              </Button>
              <Button onClick={() => handlePrint(selectedReceipt)} className="flex-1">
                <Printer className="mr-2 size-4" />
                Print
              </Button>
            </div>
          </DialogContent>
        </Dialog>
      )}
    </div>
  )
}
