'use client'

import { useState } from 'react'
import { useRouter } from 'next/navigation'
import {
  Search,
  Plus,
  Download,
  Filter,
  MoreHorizontal,
  Eye,
  Edit,
  Trash,
  CheckCircle,
  AlertCircle,
} from 'lucide-react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Badge } from '@/components/ui/badge'
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table'
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu'
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog'
import { useStudents, useCollectFee } from '@/lib/queries'
import { toast } from 'sonner'
import { format } from 'date-fns'

export default function CollectFeePage() {
  const router = useRouter()
  const { students, isLoading: loadingStudents } = useStudents()
  const { mutate: collectFee, isPending } = useCollectFee()
  const [search, setSearch] = useState('')
  const [isDialogOpen, setIsDialogOpen] = useState(false)
  const [selectedStudent, setSelectedStudent] = useState<any>(null)
  const [amount, setAmount] = useState('')
  const [paymentMethod, setPaymentMethod] = useState('cash')
  const [notes, setNotes] = useState('')

  const filteredStudents = students?.filter(
    (student) =>
      student.name.toLowerCase().includes(search.toLowerCase()) ||
      student.enrollmentId.toLowerCase().includes(search.toLowerCase())
  ) || []

  const handleCollectFee = () => {
    if (!selectedStudent || !amount) {
      toast.error('Please select a student and enter amount')
      return
    }

    collectFee(
      {
        studentId: selectedStudent.id,
        amount: parseFloat(amount),
        paymentMethod,
        notes,
        receivedDate: new Date().toISOString(),
      },
      {
        onSuccess: () => {
          toast.success(`Fee collected from ${selectedStudent.name}`)
          setIsDialogOpen(false)
          setSelectedStudent(null)
          setAmount('')
          setNotes('')
          setPaymentMethod('cash')
        },
        onError: (error) => {
          toast.error(error.message || 'Failed to collect fee')
        },
      }
    )
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
        <div>
          <h1 className="text-2xl font-bold tracking-tight">Collect Fees</h1>
          <p className="text-muted-foreground">Record student fee payments</p>
        </div>
        <Dialog open={isDialogOpen} onOpenChange={setIsDialogOpen}>
          <DialogTrigger asChild>
            <Button>
              <Plus className="mr-2 size-4" />
              Record Payment
            </Button>
          </DialogTrigger>
          <DialogContent className="max-w-md">
            <DialogHeader>
              <DialogTitle>Record Fee Payment</DialogTitle>
              <DialogDescription>Enter payment details for the student</DialogDescription>
            </DialogHeader>
            <div className="space-y-4">
              <div>
                <label className="text-sm font-medium">Select Student</label>
                <select
                  value={selectedStudent?.id || ''}
                  onChange={(e) => {
                    const student = students?.find((s) => s.id === e.target.value)
                    setSelectedStudent(student)
                  }}
                  className="w-full px-3 py-2 border border-border rounded-md text-sm"
                >
                  <option value="">Choose a student...</option>
                  {students?.map((student) => (
                    <option key={student.id} value={student.id}>
                      {student.name} ({student.enrollmentId})
                    </option>
                  ))}
                </select>
              </div>

              {selectedStudent && (
                <div className="rounded-lg bg-secondary p-3 text-sm">
                  <p className="font-medium">{selectedStudent.name}</p>
                  <p className="text-muted-foreground">{selectedStudent.batch?.name}</p>
                  <p className="text-muted-foreground">Outstanding: ₹{selectedStudent.outstandingFees || 0}</p>
                </div>
              )}

              <div>
                <label className="text-sm font-medium">Amount</label>
                <Input
                  type="number"
                  placeholder="Enter amount"
                  value={amount}
                  onChange={(e) => setAmount(e.target.value)}
                />
              </div>

              <div>
                <label className="text-sm font-medium">Payment Method</label>
                <select
                  value={paymentMethod}
                  onChange={(e) => setPaymentMethod(e.target.value)}
                  className="w-full px-3 py-2 border border-border rounded-md text-sm"
                >
                  <option value="cash">Cash</option>
                  <option value="cheque">Cheque</option>
                  <option value="bank">Bank Transfer</option>
                  <option value="upi">UPI</option>
                </select>
              </div>

              <div>
                <label className="text-sm font-medium">Notes (Optional)</label>
                <textarea
                  placeholder="Add any notes"
                  value={notes}
                  onChange={(e) => setNotes(e.target.value)}
                  className="w-full px-3 py-2 border border-border rounded-md text-sm"
                />
              </div>

              <div className="flex gap-3 pt-4">
                <Button variant="outline" onClick={() => setIsDialogOpen(false)} className="flex-1">
                  Cancel
                </Button>
                <Button onClick={handleCollectFee} disabled={isPending} className="flex-1">
                  {isPending ? 'Recording...' : 'Record Payment'}
                </Button>
              </div>
            </div>
          </DialogContent>
        </Dialog>
      </div>

      <Card>
        <CardHeader>
          <div className="flex gap-4">
            <div className="flex-1 relative">
              <Search className="absolute left-3 top-3 size-4 text-muted-foreground" />
              <Input
                placeholder="Search by name or enrollment ID"
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                className="pl-10"
              />
            </div>
            <Button variant="outline" size="icon">
              <Filter className="size-4" />
            </Button>
            <Button variant="outline" size="icon">
              <Download className="size-4" />
            </Button>
          </div>
        </CardHeader>
        <CardContent>
          <div className="overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Student Name</TableHead>
                  <TableHead>Enrollment ID</TableHead>
                  <TableHead>Batch</TableHead>
                  <TableHead className="text-right">Outstanding Fees</TableHead>
                  <TableHead className="text-center">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {loadingStudents ? (
                  <TableRow>
                    <TableCell colSpan={5} className="text-center py-8 text-muted-foreground">
                      Loading students...
                    </TableCell>
                  </TableRow>
                ) : filteredStudents.length === 0 ? (
                  <TableRow>
                    <TableCell colSpan={5} className="text-center py-8 text-muted-foreground">
                      No students found
                    </TableCell>
                  </TableRow>
                ) : (
                  filteredStudents.map((student) => (
                    <TableRow key={student.id}>
                      <TableCell className="font-medium">{student.name}</TableCell>
                      <TableCell>{student.enrollmentId}</TableCell>
                      <TableCell>{student.batch?.name}</TableCell>
                      <TableCell className="text-right">
                        <span className="font-medium">₹{(student.outstandingFees || 0).toLocaleString('en-IN')}</span>
                      </TableCell>
                      <TableCell className="text-center">
                        <DropdownMenu>
                          <DropdownMenuTrigger asChild>
                            <Button variant="ghost" size="sm">
                              <MoreHorizontal className="size-4" />
                            </Button>
                          </DropdownMenuTrigger>
                          <DropdownMenuContent align="end">
                            <DropdownMenuItem onClick={() => router.push(`/students/${student.id}`)}>
                              <Eye className="mr-2 size-4" />
                              View Profile
                            </DropdownMenuItem>
                          </DropdownMenuContent>
                        </DropdownMenu>
                      </TableCell>
                    </TableRow>
                  ))
                )}
              </TableBody>
            </Table>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
