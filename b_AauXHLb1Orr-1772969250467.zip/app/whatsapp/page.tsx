'use client'

import { useState } from 'react'
import { QrCode, Send, MessageCircle, CheckCircle, Clock, AlertCircle, Download, Filter } from 'lucide-react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Badge } from '@/components/ui/badge'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table'
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog'
import { useWhatsAppStatus, useWhatsAppMessages } from '@/lib/queries'

export default function WhatsAppPage() {
  const { status, isLoading: loadingStatus } = useWhatsAppStatus()
  const { messages, isLoading: loadingMessages } = useWhatsAppMessages()
  const [showQRDialog, setShowQRDialog] = useState(false)

  const pendingMessages = messages?.filter((m) => m.status === 'pending') || []
  const sentMessages = messages?.filter((m) => m.status === 'sent') || []
  const failedMessages = messages?.filter((m) => m.status === 'failed') || []

  return (
    <div className="space-y-6">
      <div className="flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
        <div>
          <h1 className="text-2xl font-bold tracking-tight">WhatsApp Integration</h1>
          <p className="text-muted-foreground">Manage WhatsApp messages and broadcasts</p>
        </div>
      </div>

      {/* Status Card */}
      <Card>
        <CardHeader>
          <CardTitle>Connection Status</CardTitle>
          <CardDescription>WhatsApp Business Account Setup</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          {loadingStatus ? (
            <div className="text-center text-muted-foreground">Loading...</div>
          ) : status?.isConnected ? (
            <div className="space-y-4">
              <div className="flex items-center justify-between rounded-lg bg-success/10 p-4">
                <div className="flex items-center gap-3">
                  <CheckCircle className="size-5 text-success" />
                  <div>
                    <p className="font-medium">Connected</p>
                    <p className="text-sm text-muted-foreground">
                      Phone: {status.phoneNumber}
                    </p>
                  </div>
                </div>
                <Badge variant="default">Active</Badge>
              </div>
              <p className="text-sm text-muted-foreground">
                Last synced: {status.lastSyncedAt ? new Date(status.lastSyncedAt).toLocaleString() : 'Never'}
              </p>
            </div>
          ) : (
            <div className="space-y-4">
              <div className="rounded-lg bg-warning/10 p-4 border border-warning">
                <p className="font-medium text-warning-foreground mb-2">WhatsApp Not Connected</p>
                <p className="text-sm text-warning-foreground mb-4">
                  Scan the QR code with your WhatsApp to connect your business account.
                </p>
              </div>
              <Dialog open={showQRDialog} onOpenChange={setShowQRDialog}>
                <DialogTrigger asChild>
                  <Button>
                    <QrCode className="mr-2 size-4" />
                    Show QR Code
                  </Button>
                </DialogTrigger>
                <DialogContent className="max-w-md">
                  <DialogHeader>
                    <DialogTitle>Connect WhatsApp</DialogTitle>
                    <DialogDescription>
                      Scan this QR code with your WhatsApp to connect your business account
                    </DialogDescription>
                  </DialogHeader>
                  <div className="flex items-center justify-center bg-white p-6 rounded-lg">
                    <div className="size-48 bg-muted flex items-center justify-center rounded">
                      <QrCode className="size-24 text-muted-foreground" />
                    </div>
                  </div>
                  <p className="text-xs text-muted-foreground text-center">
                    QR code will be displayed here. Scan with your WhatsApp to complete the connection.
                  </p>
                </DialogContent>
              </Dialog>
            </div>
          )}
        </CardContent>
      </Card>

      {/* Messages Tabs */}
      <Tabs defaultValue="pending">
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger className="relative">
            Pending {pendingMessages.length > 0 && (
              <Badge className="absolute -top-2 -right-2" variant="destructive" className="rounded-full">
                {pendingMessages.length}
              </Badge>
            )}
          </TabsTrigger>
          <TabsTrigger>Sent ({sentMessages.length})</TabsTrigger>
          <TabsTrigger className="relative">
            Failed {failedMessages.length > 0 && (
              <Badge className="absolute -top-2 -right-2" variant="destructive" className="rounded-full">
                {failedMessages.length}
              </Badge>
            )}
          </TabsTrigger>
        </TabsList>

        {/* Pending Messages */}
        <TabsContent value="pending" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Pending Approval</CardTitle>
              <CardDescription>Messages waiting to be sent</CardDescription>
            </CardHeader>
            <CardContent>
              {loadingMessages ? (
                <div className="text-center py-8 text-muted-foreground">Loading messages...</div>
              ) : pendingMessages.length === 0 ? (
                <div className="text-center py-8 text-muted-foreground">
                  <MessageCircle className="size-8 mx-auto mb-2 opacity-50" />
                  <p>No pending messages</p>
                </div>
              ) : (
                <div className="overflow-x-auto">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Recipient</TableHead>
                        <TableHead>Message</TableHead>
                        <TableHead>Type</TableHead>
                        <TableHead>Created</TableHead>
                        <TableHead className="text-center">Actions</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {pendingMessages.map((message) => (
                        <TableRow key={message.id}>
                          <TableCell className="font-medium">
                            {message.recipientName || message.recipientPhone}
                          </TableCell>
                          <TableCell className="max-w-xs truncate text-sm">
                            {message.content}
                          </TableCell>
                          <TableCell>
                            <Badge variant="outline">{message.type}</Badge>
                          </TableCell>
                          <TableCell className="text-sm">
                            {new Date(message.createdAt).toLocaleString()}
                          </TableCell>
                          <TableCell className="text-center">
                            <Button size="sm" variant="outline">
                              <Send className="size-3 mr-1" />
                              Send
                            </Button>
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        {/* Sent Messages */}
        <TabsContent value="sent" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Sent Messages</CardTitle>
              <CardDescription>Successfully delivered messages</CardDescription>
            </CardHeader>
            <CardContent>
              {loadingMessages ? (
                <div className="text-center py-8 text-muted-foreground">Loading messages...</div>
              ) : sentMessages.length === 0 ? (
                <div className="text-center py-8 text-muted-foreground">
                  <CheckCircle className="size-8 mx-auto mb-2 opacity-50" />
                  <p>No sent messages</p>
                </div>
              ) : (
                <div className="overflow-x-auto">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Recipient</TableHead>
                        <TableHead>Message</TableHead>
                        <TableHead>Sent At</TableHead>
                        <TableHead>Read</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {sentMessages.map((message) => (
                        <TableRow key={message.id}>
                          <TableCell className="font-medium">
                            {message.recipientName || message.recipientPhone}
                          </TableCell>
                          <TableCell className="max-w-xs truncate text-sm">
                            {message.content}
                          </TableCell>
                          <TableCell className="text-sm">
                            {new Date(message.sentAt || '').toLocaleString()}
                          </TableCell>
                          <TableCell>
                            {message.readAt ? (
                              <Badge variant="default">Read</Badge>
                            ) : (
                              <Badge variant="secondary">Delivered</Badge>
                            )}
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        {/* Failed Messages */}
        <TabsContent value="failed" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Failed Messages</CardTitle>
              <CardDescription>Messages that failed to send</CardDescription>
            </CardHeader>
            <CardContent>
              {loadingMessages ? (
                <div className="text-center py-8 text-muted-foreground">Loading messages...</div>
              ) : failedMessages.length === 0 ? (
                <div className="text-center py-8 text-muted-foreground">
                  <CheckCircle className="size-8 mx-auto mb-2 opacity-50" />
                  <p>No failed messages</p>
                </div>
              ) : (
                <div className="overflow-x-auto">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Recipient</TableHead>
                        <TableHead>Message</TableHead>
                        <TableHead>Error</TableHead>
                        <TableHead>Failed At</TableHead>
                        <TableHead className="text-center">Actions</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {failedMessages.map((message) => (
                        <TableRow key={message.id}>
                          <TableCell className="font-medium">
                            {message.recipientName || message.recipientPhone}
                          </TableCell>
                          <TableCell className="max-w-xs truncate text-sm">
                            {message.content}
                          </TableCell>
                          <TableCell className="text-sm text-destructive">
                            {message.errorMessage || 'Unknown error'}
                          </TableCell>
                          <TableCell className="text-sm">
                            {new Date(message.failedAt || '').toLocaleString()}
                          </TableCell>
                          <TableCell className="text-center">
                            <Button size="sm" variant="outline">
                              Retry
                            </Button>
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}
