'use client'

import { useState } from 'react'
import { useRouter } from 'next/navigation'
import { ArrowLeft, Send, Users } from 'lucide-react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Badge } from '@/components/ui/badge'
import { Checkbox } from '@/components/ui/checkbox'
import { useBatches, useSendBroadcast } from '@/lib/queries'
import { toast } from 'sonner'

export default function BroadcastPage() {
  const router = useRouter()
  const { batches } = useBatches()
  const { mutate: sendBroadcast, isPending } = useSendBroadcast()

  const [selectedBatches, setSelectedBatches] = useState<string[]>([])
  const [message, setMessage] = useState('')
  const [messageType, setMessageType] = useState('text')
  const [includeAttachment, setIncludeAttachment] = useState(false)

  const toggleBatch = (batchId: string) => {
    setSelectedBatches((prev) =>
      prev.includes(batchId) ? prev.filter((id) => id !== batchId) : [...prev, batchId]
    )
  }

  const estimatedRecipients = batches?.reduce((sum, batch) => {
    if (selectedBatches.includes(batch.id)) {
      return sum + (batch._count?.students || 0)
    }
    return sum
  }, 0) || 0

  const handleSend = () => {
    if (selectedBatches.length === 0 || !message.trim()) {
      toast.error('Please select at least one batch and enter a message')
      return
    }

    sendBroadcast(
      {
        batchIds: selectedBatches,
        content: message,
        type: messageType,
        scheduleTime: null,
      },
      {
        onSuccess: () => {
          toast.success(`Broadcast sent to ${estimatedRecipients} students`)
          router.push('/whatsapp')
        },
        onError: (error) => {
          toast.error(error.message || 'Failed to send broadcast')
        },
      }
    )
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center gap-4">
        <Button
          variant="outline"
          size="icon"
          onClick={() => router.back()}
        >
          <ArrowLeft className="size-4" />
        </Button>
        <div>
          <h1 className="text-2xl font-bold tracking-tight">Send Broadcast</h1>
          <p className="text-muted-foreground">Send message to multiple batches at once</p>
        </div>
      </div>

      <div className="grid gap-6 md:grid-cols-3">
        {/* Main Form */}
        <div className="md:col-span-2 space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Message Content</CardTitle>
              <CardDescription>Compose your broadcast message</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <Label htmlFor="type">Message Type</Label>
                <select
                  id="type"
                  value={messageType}
                  onChange={(e) => setMessageType(e.target.value)}
                  className="w-full px-3 py-2 border border-border rounded-md text-sm"
                >
                  <option value="text">Text Message</option>
                  <option value="image">Image</option>
                  <option value="document">Document</option>
                  <option value="template">Template</option>
                </select>
              </div>

              <div>
                <Label htmlFor="message">Message *</Label>
                <textarea
                  id="message"
                  placeholder="Enter your message here..."
                  value={message}
                  onChange={(e) => setMessage(e.target.value)}
                  className="w-full px-3 py-2 border border-border rounded-md text-sm min-h-32"
                />
                <p className="text-xs text-muted-foreground mt-1">
                  {message.length} characters
                </p>
              </div>

              {messageType !== 'text' && (
                <div>
                  <Label htmlFor="attachment">Upload File</Label>
                  <Input
                    id="attachment"
                    type="file"
                    accept={
                      messageType === 'image'
                        ? 'image/*'
                        : messageType === 'document'
                          ? '.pdf,.doc,.docx'
                          : '*'
                    }
                  />
                </div>
              )}
            </CardContent>
          </Card>

          {/* Preview */}
          <Card>
            <CardHeader>
              <CardTitle>Preview</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="rounded-lg bg-muted p-4 max-w-sm">
                <div className="space-y-2">
                  <p className="text-sm whitespace-pre-wrap break-words">{message || 'Your message will appear here...'}</p>
                  {messageType !== 'text' && (
                    <div className="bg-background rounded p-2 text-center text-xs text-muted-foreground">
                      [Attachment: {messageType.toUpperCase()}]
                    </div>
                  )}
                  <p className="text-xs text-muted-foreground text-right">
                    {new Date().toLocaleTimeString()}
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Batch Selection */}
        <div className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Select Batches</CardTitle>
              <CardDescription>Choose which batches to send to</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              {batches && batches.length > 0 ? (
                <div className="space-y-3">
                  {batches.map((batch) => (
                    <div key={batch.id} className="flex items-start gap-3">
                      <Checkbox
                        id={batch.id}
                        checked={selectedBatches.includes(batch.id)}
                        onCheckedChange={() => toggleBatch(batch.id)}
                      />
                      <label
                        htmlFor={batch.id}
                        className="flex-1 cursor-pointer text-sm"
                      >
                        <p className="font-medium">{batch.name}</p>
                        <p className="text-xs text-muted-foreground">
                          {batch._count?.students || 0} students
                        </p>
                      </label>
                    </div>
                  ))}
                </div>
              ) : (
                <p className="text-sm text-muted-foreground">No batches available</p>
              )}
            </CardContent>
          </Card>

          {/* Summary */}
          <Card>
            <CardHeader>
              <CardTitle>Summary</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <p className="text-sm text-muted-foreground">Batches Selected</p>
                <p className="text-2xl font-bold">{selectedBatches.length}</p>
              </div>

              <div>
                <p className="text-sm text-muted-foreground">Estimated Recipients</p>
                <p className="text-2xl font-bold">{estimatedRecipients}</p>
              </div>

              <Button
                onClick={handleSend}
                disabled={isPending || selectedBatches.length === 0 || !message.trim()}
                className="w-full"
              >
                <Send className="mr-2 size-4" />
                {isPending ? 'Sending...' : 'Send Broadcast'}
              </Button>

              <Button
                variant="outline"
                onClick={() => router.back()}
                className="w-full"
              >
                Cancel
              </Button>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  )
}
