'use client'

import { useState } from 'react'
import { useRouter } from 'next/navigation'
import { Plus, Search, Filter, Download, MoreHorizontal, Eye, Edit, Trash, Calendar } from 'lucide-react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Badge } from '@/components/ui/badge'
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table'
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu'
import { useExams, useDeleteExam } from '@/lib/queries'
import { toast } from 'sonner'
import { format } from 'date-fns'

export default function ExamsPage() {
  const router = useRouter()
  const { exams, isLoading } = useExams()
  const { mutate: deleteExam } = useDeleteExam()
  const [search, setSearch] = useState('')
  const [filter, setFilter] = useState('all')

  const filteredExams = exams?.filter((exam) => {
    const matchesSearch =
      exam.name.toLowerCase().includes(search.toLowerCase()) ||
      exam.subject.toLowerCase().includes(search.toLowerCase()) ||
      exam.batch?.name.toLowerCase().includes(search.toLowerCase())

    if (filter === 'upcoming') {
      return matchesSearch && new Date(exam.examDate) > new Date()
    }
    if (filter === 'completed') {
      return matchesSearch && new Date(exam.examDate) <= new Date()
    }
    return matchesSearch
  }) || []

  const handleDelete = (id: string, name: string) => {
    if (confirm(`Are you sure you want to delete "${name}"?`)) {
      deleteExam(id, {
        onSuccess: () => {
          toast.success('Exam deleted successfully')
        },
        onError: (error) => {
          toast.error(error.message || 'Failed to delete exam')
        },
      })
    }
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-col gap-4 md:flex-row md:items-center md:justify-between">
        <div>
          <h1 className="text-2xl font-bold tracking-tight">Exams</h1>
          <p className="text-muted-foreground">Manage exinations and marks</p>
        </div>
        <Button onClick={() => router.push('/exams/new')}>
          <Plus className="mr-2 size-4" />
          Create Exam
        </Button>
      </div>

      <Card>
        <CardHeader>
          <div className="flex flex-col gap-4 md:flex-row md:items-center md:gap-4">
            <div className="flex-1 relative">
              <Search className="absolute left-3 top-3 size-4 text-muted-foreground" />
              <Input
                placeholder="Search by exam name, subject, or batch"
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                className="pl-10"
              />
            </div>
            <select
              value={filter}
              onChange={(e) => setFilter(e.target.value)}
              className="px-3 py-2 border border-border rounded-md text-sm"
            >
              <option value="all">All Exams</option>
              <option value="upcoming">Upcoming</option>
              <option value="completed">Completed</option>
            </select>
            <Button variant="outline" size="icon">
              <Download className="size-4" />
            </Button>
          </div>
        </CardHeader>
        <CardContent>
          <div className="overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Exam Name</TableHead>
                  <TableHead>Subject</TableHead>
                  <TableHead>Batch</TableHead>
                  <TableHead>Date</TableHead>
                  <TableHead>Total Marks</TableHead>
                  <TableHead>Status</TableHead>
                  <TableHead className="text-center">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {isLoading ? (
                  <TableRow>
                    <TableCell colSpan={7} className="text-center py-8 text-muted-foreground">
                      Loading exams...
                    </TableCell>
                  </TableRow>
                ) : filteredExams.length === 0 ? (
                  <TableRow>
                    <TableCell colSpan={7} className="text-center py-8 text-muted-foreground">
                      No exams found
                    </TableCell>
                  </TableRow>
                ) : (
                  filteredExams.map((exam) => {
                    const isCompleted = new Date(exam.examDate) <= new Date()
                    return (
                      <TableRow key={exam.id}>
                        <TableCell className="font-medium">{exam.name}</TableCell>
                        <TableCell>{exam.subject}</TableCell>
                        <TableCell>{exam.batch?.name}</TableCell>
                        <TableCell>{format(new Date(exam.examDate), 'MMM d, yyyy')}</TableCell>
                        <TableCell>{exam.totalMarks}</TableCell>
                        <TableCell>
                          <Badge variant={isCompleted ? 'secondary' : 'outline'}>
                            {isCompleted ? 'Completed' : 'Upcoming'}
                          </Badge>
                        </TableCell>
                        <TableCell className="text-center">
                          <DropdownMenu>
                            <DropdownMenuTrigger asChild>
                              <Button variant="ghost" size="sm">
                                <MoreHorizontal className="size-4" />
                              </Button>
                            </DropdownMenuTrigger>
                            <DropdownMenuContent align="end">
                              <DropdownMenuItem onClick={() => router.push(`/exams/${exam.id}`)}>
                                <Eye className="mr-2 size-4" />
                                View
                              </DropdownMenuItem>
                              <DropdownMenuItem onClick={() => router.push(`/exams/${exam.id}/marks`)}>
                                <Edit className="mr-2 size-4" />
                                Add Marks
                              </DropdownMenuItem>
                              <DropdownMenuItem
                                onClick={() => handleDelete(exam.id, exam.name)}
                                className="text-destructive"
                              >
                                <Trash className="mr-2 size-4" />
                                Delete
                              </DropdownMenuItem>
                            </DropdownMenuContent>
                          </DropdownMenu>
                        </TableCell>
                      </TableRow>
                    )
                  })
                )}
              </TableBody>
            </Table>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
