'use client'

import { useState } from 'react'
import { useParams, useRouter } from 'next/navigation'
import { ArrowLeft, Save, Download } from 'lucide-react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table'
import { Badge } from '@/components/ui/badge'
import { useExamById, useStudentsByBatch, useSaveExamMarks } from '@/lib/queries'
import { toast } from 'sonner'

export default function ExamMarksPage() {
  const params = useParams()
  const router = useRouter()
  const examId = params.id as string

  const { exam, isLoading: loadingExam } = useExamById(examId)
  const { students, isLoading: loadingStudents } = useStudentsByBatch(exam?.batchId || '')
  const { mutate: saveMarks, isPending } = useSaveExamMarks()

  const [marks, setMarks] = useState<Record<string, number>>({})

  const handleMarkChange = (studentId: string, value: string) => {
    const numValue = value === '' ? 0 : Math.min(Math.max(parseInt(value) || 0, 0), exam?.totalMarks || 100)
    setMarks({ ...marks, [studentId]: numValue })
  }

  const handleSave = () => {
    if (Object.keys(marks).length === 0) {
      toast.error('Please enter marks for at least one student')
      return
    }

    const marksData = Object.entries(marks).map(([studentId, mark]) => ({
      studentId,
      examId,
      marks: mark,
    }))

    saveMarks(marksData, {
      onSuccess: () => {
        toast.success('Marks saved successfully')
        router.push('/exams')
      },
      onError: (error) => {
        toast.error(error.message || 'Failed to save marks')
      },
    })
  }

  if (loadingExam) {
    return <div className="text-center py-8">Loading exam...</div>
  }

  if (!exam) {
    return <div className="text-center py-8 text-destructive">Exam not found</div>
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center gap-4">
        <Button
          variant="outline"
          size="icon"
          onClick={() => router.back()}
        >
          <ArrowLeft className="size-4" />
        </Button>
        <div>
          <h1 className="text-2xl font-bold tracking-tight">Enter Marks</h1>
          <p className="text-muted-foreground">{exam.name} - {exam.subject}</p>
        </div>
      </div>

      <Card>
        <CardHeader>
          <div className="flex items-center justify-between">
            <div>
              <CardTitle>Student Marks</CardTitle>
              <CardDescription>Total marks: {exam.totalMarks}, Passing marks: {exam.passingMarks}</CardDescription>
            </div>
            <Button onClick={handleSave} disabled={isPending || Object.keys(marks).length === 0}>
              <Save className="mr-2 size-4" />
              Save Marks
            </Button>
          </div>
        </CardHeader>
        <CardContent>
          <div className="overflow-x-auto">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Roll No</TableHead>
                  <TableHead>Student Name</TableHead>
                  <TableHead className="text-right">Marks ({exam.totalMarks})</TableHead>
                  <TableHead className="text-center">Result</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {loadingStudents ? (
                  <TableRow>
                    <TableCell colSpan={4} className="text-center py-8 text-muted-foreground">
                      Loading students...
                    </TableCell>
                  </TableRow>
                ) : students && students.length > 0 ? (
                  students.map((student) => {
                    const studentMarks = marks[student.id] || 0
                    const isPassed = studentMarks >= (exam.passingMarks || 40)
                    return (
                      <TableRow key={student.id}>
                        <TableCell className="font-mono">{student.rollNo || '-'}</TableCell>
                        <TableCell className="font-medium">{student.name}</TableCell>
                        <TableCell className="text-right">
                          <Input
                            type="number"
                            min="0"
                            max={exam.totalMarks}
                            value={marks[student.id] ?? ''}
                            onChange={(e) => handleMarkChange(student.id, e.target.value)}
                            className="w-24 text-right ml-auto"
                          />
                        </TableCell>
                        <TableCell className="text-center">
                          {marks[student.id] !== undefined && (
                            <Badge variant={isPassed ? 'default' : 'secondary'}>
                              {isPassed ? 'Pass' : 'Fail'}
                            </Badge>
                          )}
                        </TableCell>
                      </TableRow>
                    )
                  })
                ) : (
                  <TableRow>
                    <TableCell colSpan={4} className="text-center py-8 text-muted-foreground">
                      No students in this batch
                    </TableCell>
                  </TableRow>
                )}
              </TableBody>
            </Table>
          </div>

          <div className="mt-6 flex gap-3">
            <Button
              variant="outline"
              onClick={() => router.back()}
              className="flex-1"
            >
              Cancel
            </Button>
            <Button
              onClick={handleSave}
              disabled={isPending || Object.keys(marks).length === 0}
              className="flex-1"
            >
              {isPending ? 'Saving...' : 'Save Marks'}
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
