'use client'

import { useState } from 'react'
import { Save, Download, Upload, Database, Key, Bell, Shield, AlertCircle, CheckCircle } from 'lucide-react'
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card'
import { Button } from '@/components/ui/button'
import { Input } from '@/components/ui/input'
import { Label } from '@/components/ui/label'
import { Badge } from '@/components/ui/badge'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { Switch } from '@/components/ui/switch'
import { useSettings, useUpdateSettings, useBackupDatabase } from '@/lib/queries'
import { toast } from 'sonner'

export default function SettingsPage() {
  const { settings, isLoading } = useSettings()
  const { mutate: updateSettings, isPending: updating } = useUpdateSettings()
  const { mutate: backupDatabase, isPending: backingUp } = useBackupDatabase()

  const [formData, setFormData] = useState({
    academyName: settings?.academyName || '',
    academyAddress: settings?.academyAddress || '',
    academyPhone: settings?.academyPhone || '',
    academyEmail: settings?.academyEmail || '',
    academyLogo: settings?.academyLogo || '',
    academyReg: settings?.academyReg || '',
    enableAttendance: settings?.enableAttendance ?? true,
    enableFees: settings?.enableFees ?? true,
    enableExams: settings?.enableExams ?? true,
    enableWhatsApp: settings?.enableWhatsApp ?? false,
    defaultFeeAmount: settings?.defaultFeeAmount || '',
    feeFrequency: settings?.feeFrequency || 'monthly',
    academicYear: settings?.academicYear || new Date().getFullYear().toString(),
  })

  const handleSave = () => {
    updateSettings(formData, {
      onSuccess: () => {
        toast.success('Settings saved successfully')
      },
      onError: (error) => {
        toast.error(error.message || 'Failed to save settings')
      },
    })
  }

  const handleBackup = () => {
    backupDatabase(undefined, {
      onSuccess: () => {
        toast.success('Database backup created successfully')
      },
      onError: (error) => {
        toast.error(error.message || 'Failed to backup database')
      },
    })
  }

  if (isLoading) {
    return <div className="text-center py-8">Loading settings...</div>
  }

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold tracking-tight">Settings</h1>
        <p className="text-muted-foreground">Manage academy settings and system configuration</p>
      </div>

      <Tabs defaultValue="academy">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger>Academy Info</TabsTrigger>
          <TabsTrigger>Features</TabsTrigger>
          <TabsTrigger>Fees</TabsTrigger>
          <TabsTrigger>Backup</TabsTrigger>
        </TabsList>

        {/* Academy Info */}
        <TabsContent value="academy" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Academy Information</CardTitle>
              <CardDescription>Update your academy details</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="grid gap-4 md:grid-cols-2">
                <div>
                  <Label htmlFor="name">Academy Name</Label>
                  <Input
                    id="name"
                    value={formData.academyName}
                    onChange={(e) =>
                      setFormData({ ...formData, academyName: e.target.value })
                    }
                    placeholder="e.g., TIPS Academy"
                  />
                </div>

                <div>
                  <Label htmlFor="reg">Registration Number</Label>
                  <Input
                    id="reg"
                    value={formData.academyReg}
                    onChange={(e) =>
                      setFormData({ ...formData, academyReg: e.target.value })
                    }
                    placeholder="Academy registration number"
                  />
                </div>

                <div className="md:col-span-2">
                  <Label htmlFor="address">Address</Label>
                  <textarea
                    id="address"
                    value={formData.academyAddress}
                    onChange={(e) =>
                      setFormData({ ...formData, academyAddress: e.target.value })
                    }
                    placeholder="Full address"
                    className="w-full px-3 py-2 border border-border rounded-md text-sm min-h-20"
                  />
                </div>

                <div>
                  <Label htmlFor="phone">Phone Number</Label>
                  <Input
                    id="phone"
                    value={formData.academyPhone}
                    onChange={(e) =>
                      setFormData({ ...formData, academyPhone: e.target.value })
                    }
                    placeholder="+91 XXXXX XXXXX"
                  />
                </div>

                <div>
                  <Label htmlFor="email">Email Address</Label>
                  <Input
                    id="email"
                    type="email"
                    value={formData.academyEmail}
                    onChange={(e) =>
                      setFormData({ ...formData, academyEmail: e.target.value })
                    }
                    placeholder="info@academy.com"
                  />
                </div>

                <div>
                  <Label htmlFor="year">Academic Year</Label>
                  <Input
                    id="year"
                    value={formData.academicYear}
                    onChange={(e) =>
                      setFormData({ ...formData, academicYear: e.target.value })
                    }
                    placeholder="2024-2025"
                  />
                </div>
              </div>

              <Button onClick={handleSave} disabled={updating}>
                <Save className="mr-2 size-4" />
                {updating ? 'Saving...' : 'Save Changes'}
              </Button>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Features */}
        <TabsContent value="features" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Feature Management</CardTitle>
              <CardDescription>Enable or disable features</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="space-y-4">
                <div className="flex items-center justify-between p-4 border border-border rounded-lg">
                  <div>
                    <p className="font-medium">Attendance Module</p>
                    <p className="text-sm text-muted-foreground">Track student attendance</p>
                  </div>
                  <Switch
                    checked={formData.enableAttendance}
                    onCheckedChange={(checked) =>
                      setFormData({ ...formData, enableAttendance: checked })
                    }
                  />
                </div>

                <div className="flex items-center justify-between p-4 border border-border rounded-lg">
                  <div>
                    <p className="font-medium">Fee Management</p>
                    <p className="text-sm text-muted-foreground">Manage student fees</p>
                  </div>
                  <Switch
                    checked={formData.enableFees}
                    onCheckedChange={(checked) =>
                      setFormData({ ...formData, enableFees: checked })
                    }
                  />
                </div>

                <div className="flex items-center justify-between p-4 border border-border rounded-lg">
                  <div>
                    <p className="font-medium">Exam Module</p>
                    <p className="text-sm text-muted-foreground">Create and manage exams</p>
                  </div>
                  <Switch
                    checked={formData.enableExams}
                    onCheckedChange={(checked) =>
                      setFormData({ ...formData, enableExams: checked })
                    }
                  />
                </div>

                <div className="flex items-center justify-between p-4 border border-border rounded-lg">
                  <div>
                    <p className="font-medium">WhatsApp Integration</p>
                    <p className="text-sm text-muted-foreground">Send messages via WhatsApp</p>
                  </div>
                  <Switch
                    checked={formData.enableWhatsApp}
                    onCheckedChange={(checked) =>
                      setFormData({ ...formData, enableWhatsApp: checked })
                    }
                  />
                </div>
              </div>

              <Button onClick={handleSave} disabled={updating}>
                <Save className="mr-2 size-4" />
                {updating ? 'Saving...' : 'Save Changes'}
              </Button>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Fees */}
        <TabsContent value="fees" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Fee Configuration</CardTitle>
              <CardDescription>Set default fee amounts and frequency</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="grid gap-4 md:grid-cols-2">
                <div>
                  <Label htmlFor="defaultFee">Default Fee Amount (₹)</Label>
                  <Input
                    id="defaultFee"
                    type="number"
                    value={formData.defaultFeeAmount}
                    onChange={(e) =>
                      setFormData({
                        ...formData,
                        defaultFeeAmount: e.target.value,
                      })
                    }
                    placeholder="0"
                  />
                </div>

                <div>
                  <Label htmlFor="frequency">Fee Frequency</Label>
                  <select
                    id="frequency"
                    value={formData.feeFrequency}
                    onChange={(e) =>
                      setFormData({
                        ...formData,
                        feeFrequency: e.target.value,
                      })
                    }
                    className="w-full px-3 py-2 border border-border rounded-md text-sm"
                  >
                    <option value="monthly">Monthly</option>
                    <option value="quarterly">Quarterly</option>
                    <option value="half-yearly">Half Yearly</option>
                    <option value="yearly">Yearly</option>
                  </select>
                </div>
              </div>

              <Button onClick={handleSave} disabled={updating}>
                <Save className="mr-2 size-4" />
                {updating ? 'Saving...' : 'Save Changes'}
              </Button>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Backup */}
        <TabsContent value="backup" className="space-y-4">
          <Card>
            <CardHeader>
              <CardTitle>Database Management</CardTitle>
              <CardDescription>Backup and restore your data</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="space-y-4">
                <div className="rounded-lg border border-border p-4">
                  <div className="flex items-start justify-between">
                    <div>
                      <p className="font-medium flex items-center gap-2">
                        <Database className="size-4" />
                        Automated Backups
                      </p>
                      <p className="text-sm text-muted-foreground mt-1">
                        Daily automatic backups are enabled
                      </p>
                      <div className="mt-3 space-y-2 text-sm">
                        <p>Last backup: 2024-01-15 03:30 AM</p>
                        <p>Next backup: 2024-01-16 03:30 AM</p>
                      </div>
                    </div>
                    <Badge variant="default" className="flex items-center gap-1">
                      <CheckCircle className="size-3" />
                      Active
                    </Badge>
                  </div>
                </div>

                <Button onClick={handleBackup} disabled={backingUp} className="w-full">
                  <Download className="mr-2 size-4" />
                  {backingUp ? 'Creating backup...' : 'Create Manual Backup'}
                </Button>

                <Button variant="outline" className="w-full">
                  <Upload className="mr-2 size-4" />
                  Restore from Backup
                </Button>
              </div>

              <div className="rounded-lg bg-info/10 border border-info p-4">
                <div className="flex gap-3">
                  <AlertCircle className="size-5 text-info flex-shrink-0 mt-0.5" />
                  <div className="text-sm">
                    <p className="font-medium text-info-foreground">Pro Tip</p>
                    <p className="text-info-foreground">
                      We recommend creating a manual backup before making major changes to your academy setup.
                    </p>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}
