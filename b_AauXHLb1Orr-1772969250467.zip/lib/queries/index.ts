'use client'

import useSWR from 'swr'
import { toast } from 'sonner'
import {
  batchesApi,
  groupsApi,
  studentsApi,
  attendanceApi,
  feesApi,
  examsApi,
  whatsappApi,
  settingsApi,
  dashboardApi,
} from '@/lib/api'
import type {
  BatchFormData,
  GroupFormData,
  StudentFormData,
  StudentFilters,
  AttendanceFilters,
  AttendanceMarkPayload,
  FeeFilters,
  FeePaymentPayload,
  ExamFormData,
  ExamFilters,
  MarksEntryPayload,
  BroadcastPayload,
  MessageFilters,
  AcademySettings,
} from '@/lib/types'

// ============ BATCHES ============
export function useBatches() {
  const { data, error, isLoading, mutate } = useSWR('batches', async () => {
    const response = await batchesApi.getAll()
    if (!response.success) throw new Error(response.error)
    return response.data
  })

  return {
    batches: data ?? [],
    isLoading,
    error,
    refresh: mutate,
  }
}

export function useBatch(id: string) {
  const { data, error, isLoading, mutate } = useSWR(
    id ? `batch-${id}` : null,
    async () => {
      const response = await batchesApi.getById(id)
      if (!response.success) throw new Error(response.error)
      return response.data
    }
  )

  return {
    batch: data,
    isLoading,
    error,
    refresh: mutate,
  }
}

export function useBatchMutations() {
  const { refresh } = useBatches()

  const createBatch = async (data: BatchFormData) => {
    const response = await batchesApi.create(data)
    if (response.success) {
      toast.success('Batch created successfully')
      refresh()
    } else {
      toast.error(response.error || 'Failed to create batch')
    }
    return response
  }

  const updateBatch = async (id: string, data: Partial<BatchFormData>) => {
    const response = await batchesApi.update(id, data)
    if (response.success) {
      toast.success('Batch updated successfully')
      refresh()
    } else {
      toast.error(response.error || 'Failed to update batch')
    }
    return response
  }

  const archiveBatch = async (id: string) => {
    const response = await batchesApi.archive(id)
    if (response.success) {
      toast.success('Batch archived successfully')
      refresh()
    } else {
      toast.error(response.error || 'Failed to archive batch')
    }
    return response
  }

  const deleteBatch = async (id: string) => {
    const response = await batchesApi.delete(id)
    if (response.success) {
      toast.success('Batch deleted successfully')
      refresh()
    } else {
      toast.error(response.error || 'Failed to delete batch')
    }
    return response
  }

  return { createBatch, updateBatch, archiveBatch, deleteBatch }
}

// ============ GROUPS ============
export function useGroups(batchId?: string) {
  const { data, error, isLoading, mutate } = useSWR(
    `groups${batchId ? `-${batchId}` : ''}`,
    async () => {
      const response = await groupsApi.getAll(batchId)
      if (!response.success) throw new Error(response.error)
      return response.data
    }
  )

  return {
    groups: data ?? [],
    isLoading,
    error,
    refresh: mutate,
  }
}

export function useGroupMutations() {
  const createGroup = async (data: GroupFormData, onSuccess?: () => void) => {
    const response = await groupsApi.create(data)
    if (response.success) {
      toast.success('Group created successfully')
      onSuccess?.()
    } else {
      toast.error(response.error || 'Failed to create group')
    }
    return response
  }

  const updateGroup = async (
    id: string,
    data: Partial<GroupFormData>,
    onSuccess?: () => void
  ) => {
    const response = await groupsApi.update(id, data)
    if (response.success) {
      toast.success('Group updated successfully')
      onSuccess?.()
    } else {
      toast.error(response.error || 'Failed to update group')
    }
    return response
  }

  const deleteGroup = async (id: string, onSuccess?: () => void) => {
    const response = await groupsApi.delete(id)
    if (response.success) {
      toast.success('Group deleted successfully')
      onSuccess?.()
    } else {
      toast.error(response.error || 'Failed to delete group')
    }
    return response
  }

  return { createGroup, updateGroup, deleteGroup }
}

// ============ STUDENTS ============
export function useStudents(filters?: StudentFilters) {
  const filterKey = filters ? JSON.stringify(filters) : ''
  const { data, error, isLoading, mutate } = useSWR(
    `students-${filterKey}`,
    async () => {
      const response = await studentsApi.getAll(filters)
      if (!response.success) throw new Error(response.error)
      return response.data
    }
  )

  return {
    students: data ?? [],
    isLoading,
    error,
    refresh: mutate,
  }
}

export function useStudent(id: string) {
  const { data, error, isLoading, mutate } = useSWR(
    id ? `student-${id}` : null,
    async () => {
      const response = await studentsApi.getById(id)
      if (!response.success) throw new Error(response.error)
      return response.data
    }
  )

  return {
    student: data,
    isLoading,
    error,
    refresh: mutate,
  }
}

export function useStudentMutations() {
  const createStudent = async (data: StudentFormData, onSuccess?: () => void) => {
    const response = await studentsApi.create(data)
    if (response.success) {
      toast.success('Student added successfully')
      onSuccess?.()
    } else {
      toast.error(response.error || 'Failed to add student')
    }
    return response
  }

  const updateStudent = async (
    id: string,
    data: Partial<StudentFormData>,
    onSuccess?: () => void
  ) => {
    const response = await studentsApi.update(id, data)
    if (response.success) {
      toast.success('Student updated successfully')
      onSuccess?.()
    } else {
      toast.error(response.error || 'Failed to update student')
    }
    return response
  }

  const updatePhoto = async (id: string, photo: File, onSuccess?: () => void) => {
    const response = await studentsApi.updatePhoto(id, photo)
    if (response.success) {
      toast.success('Photo updated successfully')
      onSuccess?.()
    } else {
      toast.error(response.error || 'Failed to update photo')
    }
    return response
  }

  const toggleStatus = async (id: string, onSuccess?: () => void) => {
    const response = await studentsApi.toggleStatus(id)
    if (response.success) {
      toast.success('Student status updated')
      onSuccess?.()
    } else {
      toast.error(response.error || 'Failed to update status')
    }
    return response
  }

  const deleteStudent = async (id: string, onSuccess?: () => void) => {
    const response = await studentsApi.delete(id)
    if (response.success) {
      toast.success('Student deleted successfully')
      onSuccess?.()
    } else {
      toast.error(response.error || 'Failed to delete student')
    }
    return response
  }

  return { createStudent, updateStudent, updatePhoto, toggleStatus, deleteStudent }
}

// ============ ATTENDANCE ============
export function useAttendanceByDate(date: string, filters?: AttendanceFilters) {
  const filterKey = filters ? JSON.stringify(filters) : ''
  const { data, error, isLoading, mutate } = useSWR(
    date ? `attendance-${date}-${filterKey}` : null,
    async () => {
      const response = await attendanceApi.getByDate(date, filters)
      if (!response.success) throw new Error(response.error)
      return response.data
    }
  )

  return {
    records: data ?? [],
    isLoading,
    error,
    refresh: mutate,
  }
}

export function useStudentAttendance(studentId: string, month?: string) {
  const { data, error, isLoading, mutate } = useSWR(
    studentId ? `attendance-student-${studentId}-${month || 'all'}` : null,
    async () => {
      const response = await attendanceApi.getByStudent(studentId, month)
      if (!response.success) throw new Error(response.error)
      return response.data
    }
  )

  return {
    records: data ?? [],
    isLoading,
    error,
    refresh: mutate,
  }
}

export function useAttendanceSummary(filters: AttendanceFilters) {
  const filterKey = JSON.stringify(filters)
  const { data, error, isLoading, mutate } = useSWR(
    `attendance-summary-${filterKey}`,
    async () => {
      const response = await attendanceApi.getSummary(filters)
      if (!response.success) throw new Error(response.error)
      return response.data
    }
  )

  return {
    summary: data ?? [],
    isLoading,
    error,
    refresh: mutate,
  }
}

export function useAttendanceMutations() {
  const markAttendance = async (
    date: string,
    records: AttendanceMarkPayload[],
    onSuccess?: () => void
  ) => {
    const response = await attendanceApi.mark(date, records)
    if (response.success) {
      toast.success('Attendance saved successfully')
      onSuccess?.()
    } else {
      toast.error(response.error || 'Failed to save attendance')
    }
    return response
  }

  const markBulk = async (
    date: string,
    batchId: string,
    status: 'present' | 'absent',
    onSuccess?: () => void
  ) => {
    const response = await attendanceApi.markBulk(date, batchId, status)
    if (response.success) {
      toast.success(`All students marked ${status}`)
      onSuccess?.()
    } else {
      toast.error(response.error || 'Failed to mark attendance')
    }
    return response
  }

  return { markAttendance, markBulk }
}

// ============ FEES ============
export function useFees(filters?: FeeFilters) {
  const filterKey = filters ? JSON.stringify(filters) : ''
  const { data, error, isLoading, mutate } = useSWR(
    `fees-${filterKey}`,
    async () => {
      const response = await feesApi.getAll(filters)
      if (!response.success) throw new Error(response.error)
      return response.data
    }
  )

  return {
    fees: data ?? [],
    isLoading,
    error,
    refresh: mutate,
  }
}

export function useStudentFees(studentId: string) {
  const { data, error, isLoading, mutate } = useSWR(
    studentId ? `fees-student-${studentId}` : null,
    async () => {
      const response = await feesApi.getByStudent(studentId)
      if (!response.success) throw new Error(response.error)
      return response.data
    }
  )

  return {
    fees: data ?? [],
    isLoading,
    error,
    refresh: mutate,
  }
}

export function useFeeSummary(month?: string) {
  const { data, error, isLoading, mutate } = useSWR(
    `fee-summary-${month || 'current'}`,
    async () => {
      const response = await feesApi.getSummary(month)
      if (!response.success) throw new Error(response.error)
      return response.data
    }
  )

  return {
    summary: data,
    isLoading,
    error,
    refresh: mutate,
  }
}

export function useOutstandingFees(batchId?: string) {
  const { data, error, isLoading, mutate } = useSWR(
    `fees-outstanding-${batchId || 'all'}`,
    async () => {
      const response = await feesApi.getOutstanding(batchId)
      if (!response.success) throw new Error(response.error)
      return response.data
    }
  )

  return {
    outstanding: data ?? [],
    isLoading,
    error,
    refresh: mutate,
  }
}

export function useFeeMutations() {
  const generateFees = async (month: string, batchId?: string, onSuccess?: () => void) => {
    const response = await feesApi.generate(month, batchId)
    if (response.success) {
      toast.success(`Generated fees for ${response.data?.generated} students`)
      onSuccess?.()
    } else {
      toast.error(response.error || 'Failed to generate fees')
    }
    return response
  }

  const recordPayment = async (data: FeePaymentPayload, onSuccess?: () => void) => {
    const response = await feesApi.recordPayment(data)
    if (response.success) {
      toast.success('Payment recorded successfully')
      onSuccess?.()
    } else {
      toast.error(response.error || 'Failed to record payment')
    }
    return response
  }

  return { generateFees, recordPayment }
}

// ============ EXAMS ============
export function useExams(filters?: ExamFilters) {
  const filterKey = filters ? JSON.stringify(filters) : ''
  const { data, error, isLoading, mutate } = useSWR(
    `exams-${filterKey}`,
    async () => {
      const response = await examsApi.getAll(filters)
      if (!response.success) throw new Error(response.error)
      return response.data
    }
  )

  return {
    exams: data ?? [],
    isLoading,
    error,
    refresh: mutate,
  }
}

export function useExam(id: string) {
  const { data, error, isLoading, mutate } = useSWR(
    id ? `exam-${id}` : null,
    async () => {
      const response = await examsApi.getById(id)
      if (!response.success) throw new Error(response.error)
      return response.data
    }
  )

  return {
    exam: data,
    isLoading,
    error,
    refresh: mutate,
  }
}

export function useExamResults(examId: string) {
  const { data, error, isLoading, mutate } = useSWR(
    examId ? `exam-results-${examId}` : null,
    async () => {
      const response = await examsApi.getResults(examId)
      if (!response.success) throw new Error(response.error)
      return response.data
    }
  )

  return {
    results: data ?? [],
    isLoading,
    error,
    refresh: mutate,
  }
}

export function useExamMutations() {
  const createExam = async (data: ExamFormData, onSuccess?: () => void) => {
    const response = await examsApi.create(data)
    if (response.success) {
      toast.success('Exam created successfully')
      onSuccess?.()
    } else {
      toast.error(response.error || 'Failed to create exam')
    }
    return response
  }

  const updateExam = async (
    id: string,
    data: Partial<ExamFormData>,
    onSuccess?: () => void
  ) => {
    const response = await examsApi.update(id, data)
    if (response.success) {
      toast.success('Exam updated successfully')
      onSuccess?.()
    } else {
      toast.error(response.error || 'Failed to update exam')
    }
    return response
  }

  const lockExam = async (id: string, onSuccess?: () => void) => {
    const response = await examsApi.lock(id)
    if (response.success) {
      toast.success('Exam locked successfully')
      onSuccess?.()
    } else {
      toast.error(response.error || 'Failed to lock exam')
    }
    return response
  }

  const deleteExam = async (id: string, onSuccess?: () => void) => {
    const response = await examsApi.delete(id)
    if (response.success) {
      toast.success('Exam deleted successfully')
      onSuccess?.()
    } else {
      toast.error(response.error || 'Failed to delete exam')
    }
    return response
  }

  const saveMarks = async (
    examId: string,
    marks: MarksEntryPayload[],
    onSuccess?: () => void
  ) => {
    const response = await examsApi.saveMarks(examId, marks)
    if (response.success) {
      toast.success('Marks saved successfully')
      onSuccess?.()
    } else {
      toast.error(response.error || 'Failed to save marks')
    }
    return response
  }

  return { createExam, updateExam, lockExam, deleteExam, saveMarks }
}

// ============ WHATSAPP ============
export function useWhatsAppStatus() {
  const { data, error, isLoading, mutate } = useSWR(
    'whatsapp-status',
    async () => {
      const response = await whatsappApi.getStatus()
      if (!response.success) throw new Error(response.error)
      return response.data
    },
    { refreshInterval: 5000 } // Poll every 5 seconds
  )

  return {
    status: data,
    isLoading,
    error,
    refresh: mutate,
  }
}

export function useWhatsAppQueue() {
  const { data, error, isLoading, mutate } = useSWR(
    'whatsapp-queue',
    async () => {
      const response = await whatsappApi.getQueue()
      if (!response.success) throw new Error(response.error)
      return response.data
    }
  )

  return {
    queue: data ?? [],
    isLoading,
    error,
    refresh: mutate,
  }
}

export function useWhatsAppLogs(filters?: MessageFilters) {
  const filterKey = filters ? JSON.stringify(filters) : ''
  const { data, error, isLoading, mutate } = useSWR(
    `whatsapp-logs-${filterKey}`,
    async () => {
      const response = await whatsappApi.getLogs(filters)
      if (!response.success) throw new Error(response.error)
      return response.data
    }
  )

  return {
    logs: data ?? [],
    isLoading,
    error,
    refresh: mutate,
  }
}

export function useStudentMessages(studentId: string) {
  const { data, error, isLoading, mutate } = useSWR(
    studentId ? `whatsapp-student-${studentId}` : null,
    async () => {
      const response = await whatsappApi.getStudentMessages(studentId)
      if (!response.success) throw new Error(response.error)
      return response.data
    }
  )

  return {
    messages: data ?? [],
    isLoading,
    error,
    refresh: mutate,
  }
}

export function useWhatsAppMutations() {
  const connect = async (onSuccess?: () => void) => {
    const response = await whatsappApi.connect()
    if (response.success) {
      toast.success('WhatsApp connection initiated')
      onSuccess?.()
    } else {
      toast.error(response.error || 'Failed to connect WhatsApp')
    }
    return response
  }

  const disconnect = async (onSuccess?: () => void) => {
    const response = await whatsappApi.disconnect()
    if (response.success) {
      toast.success('WhatsApp disconnected')
      onSuccess?.()
    } else {
      toast.error(response.error || 'Failed to disconnect')
    }
    return response
  }

  const approveMessage = async (id: string, onSuccess?: () => void) => {
    const response = await whatsappApi.approveMessage(id)
    if (response.success) {
      toast.success('Message approved')
      onSuccess?.()
    } else {
      toast.error(response.error || 'Failed to approve message')
    }
    return response
  }

  const rejectMessage = async (id: string, onSuccess?: () => void) => {
    const response = await whatsappApi.rejectMessage(id)
    if (response.success) {
      toast.success('Message rejected')
      onSuccess?.()
    } else {
      toast.error(response.error || 'Failed to reject message')
    }
    return response
  }

  const retryMessage = async (id: string, onSuccess?: () => void) => {
    const response = await whatsappApi.retryMessage(id)
    if (response.success) {
      toast.success('Message queued for retry')
      onSuccess?.()
    } else {
      toast.error(response.error || 'Failed to retry message')
    }
    return response
  }

  const broadcast = async (data: BroadcastPayload, onSuccess?: () => void) => {
    const response = await whatsappApi.broadcast(data)
    if (response.success) {
      toast.success(`Broadcast queued for ${response.data?.queued} recipients`)
      onSuccess?.()
    } else {
      toast.error(response.error || 'Failed to send broadcast')
    }
    return response
  }

  return { connect, disconnect, approveMessage, rejectMessage, retryMessage, broadcast }
}

// ============ SETTINGS ============
export function useSettings() {
  const { data, error, isLoading, mutate } = useSWR('settings', async () => {
    const response = await settingsApi.get()
    if (!response.success) throw new Error(response.error)
    return response.data
  })

  return {
    settings: data,
    isLoading,
    error,
    refresh: mutate,
  }
}

export function useSettingsMutations() {
  const { refresh } = useSettings()

  const updateSettings = async (data: Partial<AcademySettings>) => {
    const response = await settingsApi.update(data)
    if (response.success) {
      toast.success('Settings updated')
      refresh()
    } else {
      toast.error(response.error || 'Failed to update settings')
    }
    return response
  }

  const uploadLogo = async (logo: File) => {
    const response = await settingsApi.uploadLogo(logo)
    if (response.success) {
      toast.success('Logo uploaded')
      refresh()
    } else {
      toast.error(response.error || 'Failed to upload logo')
    }
    return response
  }

  const backup = async () => {
    const response = await settingsApi.backup()
    if (response.success) {
      toast.success('Backup created successfully')
    } else {
      toast.error(response.error || 'Failed to create backup')
    }
    return response
  }

  const restore = async (backupPath: string) => {
    const response = await settingsApi.restore(backupPath)
    if (response.success) {
      toast.success('Backup restored successfully')
      refresh()
    } else {
      toast.error(response.error || 'Failed to restore backup')
    }
    return response
  }

  return { updateSettings, uploadLogo, backup, restore }
}

// ============ DASHBOARD ============
export function useDashboardStats() {
  const { data, error, isLoading, mutate } = useSWR(
    'dashboard-stats',
    async () => {
      const response = await dashboardApi.getStats()
      if (!response.success) throw new Error(response.error)
      return response.data
    },
    { refreshInterval: 30000 } // Refresh every 30 seconds
  )

  return {
    stats: data,
    isLoading,
    error,
    refresh: mutate,
  }
}
