import type {
  ApiResponse,
  Batch,
  BatchFormData,
  Group,
  GroupFormData,
  Student,
  StudentFormData,
  StudentFilters,
  AttendanceRecord,
  AttendanceMarkPayload,
  AttendanceFilters,
  AttendanceSummary,
  FeeRecord,
  FeePaymentPayload,
  FeeFilters,
  FeeSummary,
  Exam,
  ExamFormData,
  ExamResult,
  MarksEntryPayload,
  ExamFilters,
  WhatsAppStatus,
  WhatsAppMessage,
  BroadcastPayload,
  MessageFilters,
  AcademySettings,
  DashboardStats,
} from './types'

// Base API URL - configurable for Electron
const API_BASE_URL = process.env.NEXT_PUBLIC_API_URL || 'http://localhost:3001/api'

// Generic fetch wrapper with error handling
async function apiFetch<T>(
  endpoint: string,
  options: RequestInit = {}
): Promise<ApiResponse<T>> {
  try {
    const response = await fetch(`${API_BASE_URL}${endpoint}`, {
      ...options,
      headers: {
        'Content-Type': 'application/json',
        ...options.headers,
      },
    })

    const data = await response.json()

    if (!response.ok) {
      return {
        success: false,
        error: data.message || data.error || 'An error occurred',
      }
    }

    return {
      success: true,
      data: data.data ?? data,
    }
  } catch (error) {
    console.error('API Error:', error)
    return {
      success: false,
      error: error instanceof Error ? error.message : 'Network error',
    }
  }
}

// File upload wrapper
async function apiUpload<T>(
  endpoint: string,
  formData: FormData
): Promise<ApiResponse<T>> {
  try {
    const response = await fetch(`${API_BASE_URL}${endpoint}`, {
      method: 'POST',
      body: formData,
    })

    const data = await response.json()

    if (!response.ok) {
      return {
        success: false,
        error: data.message || data.error || 'Upload failed',
      }
    }

    return {
      success: true,
      data: data.data ?? data,
    }
  } catch (error) {
    console.error('Upload Error:', error)
    return {
      success: false,
      error: error instanceof Error ? error.message : 'Upload failed',
    }
  }
}

// Build query string from filters
function buildQueryString(filters: Record<string, unknown>): string {
  const params = new URLSearchParams()
  Object.entries(filters).forEach(([key, value]) => {
    if (value !== undefined && value !== null && value !== '' && value !== 'all') {
      params.append(key, String(value))
    }
  })
  const queryString = params.toString()
  return queryString ? `?${queryString}` : ''
}

// ============ BATCHES ============
export const batchesApi = {
  getAll: () => apiFetch<Batch[]>('/batches'),
  
  getById: (id: string) => apiFetch<Batch>(`/batches/${id}`),
  
  create: (data: BatchFormData) =>
    apiFetch<Batch>('/batches', {
      method: 'POST',
      body: JSON.stringify(data),
    }),
  
  update: (id: string, data: Partial<BatchFormData>) =>
    apiFetch<Batch>(`/batches/${id}`, {
      method: 'PUT',
      body: JSON.stringify(data),
    }),
  
  archive: (id: string) =>
    apiFetch<Batch>(`/batches/${id}/archive`, {
      method: 'POST',
    }),
  
  delete: (id: string) =>
    apiFetch<void>(`/batches/${id}`, {
      method: 'DELETE',
    }),
}

// ============ GROUPS ============
export const groupsApi = {
  getAll: (batchId?: string) =>
    apiFetch<Group[]>(`/groups${batchId ? `?batchId=${batchId}` : ''}`),
  
  getById: (id: string) => apiFetch<Group>(`/groups/${id}`),
  
  create: (data: GroupFormData) =>
    apiFetch<Group>('/groups', {
      method: 'POST',
      body: JSON.stringify(data),
    }),
  
  update: (id: string, data: Partial<GroupFormData>) =>
    apiFetch<Group>(`/groups/${id}`, {
      method: 'PUT',
      body: JSON.stringify(data),
    }),
  
  delete: (id: string) =>
    apiFetch<void>(`/groups/${id}`, {
      method: 'DELETE',
    }),
}

// ============ STUDENTS ============
export const studentsApi = {
  getAll: (filters?: StudentFilters) =>
    apiFetch<Student[]>(`/students${filters ? buildQueryString(filters) : ''}`),
  
  getById: (id: string) => apiFetch<Student>(`/students/${id}`),
  
  create: (data: StudentFormData) => {
    if (data.photo) {
      const formData = new FormData()
      Object.entries(data).forEach(([key, value]) => {
        if (value !== undefined && value !== null) {
          if (key === 'photo' && value instanceof File) {
            formData.append('photo', value)
          } else {
            formData.append(key, String(value))
          }
        }
      })
      return apiUpload<Student>('/students', formData)
    }
    return apiFetch<Student>('/students', {
      method: 'POST',
      body: JSON.stringify(data),
    })
  },
  
  update: (id: string, data: Partial<StudentFormData>) => {
    if (data.photo) {
      const formData = new FormData()
      Object.entries(data).forEach(([key, value]) => {
        if (value !== undefined && value !== null) {
          if (key === 'photo' && value instanceof File) {
            formData.append('photo', value)
          } else {
            formData.append(key, String(value))
          }
        }
      })
      formData.append('_method', 'PUT')
      return apiUpload<Student>(`/students/${id}`, formData)
    }
    return apiFetch<Student>(`/students/${id}`, {
      method: 'PUT',
      body: JSON.stringify(data),
    })
  },
  
  updatePhoto: (id: string, photo: File) => {
    const formData = new FormData()
    formData.append('photo', photo)
    return apiUpload<{ photoUrl: string }>(`/students/${id}/photo`, formData)
  },
  
  toggleStatus: (id: string) =>
    apiFetch<Student>(`/students/${id}/toggle-status`, {
      method: 'POST',
    }),
  
  delete: (id: string) =>
    apiFetch<void>(`/students/${id}`, {
      method: 'DELETE',
    }),
}

// ============ ATTENDANCE ============
export const attendanceApi = {
  getByDate: (date: string, filters?: AttendanceFilters) =>
    apiFetch<AttendanceRecord[]>(
      `/attendance/date/${date}${filters ? buildQueryString(filters) : ''}`
    ),
  
  getByStudent: (studentId: string, month?: string) =>
    apiFetch<AttendanceRecord[]>(
      `/attendance/student/${studentId}${month ? `?month=${month}` : ''}`
    ),
  
  getSummary: (filters: AttendanceFilters) =>
    apiFetch<AttendanceSummary[]>(`/attendance/summary${buildQueryString(filters)}`),
  
  mark: (date: string, records: AttendanceMarkPayload[]) =>
    apiFetch<AttendanceRecord[]>(`/attendance/mark`, {
      method: 'POST',
      body: JSON.stringify({ date, records }),
    }),
  
  markBulk: (date: string, batchId: string, status: 'present' | 'absent') =>
    apiFetch<AttendanceRecord[]>(`/attendance/mark-bulk`, {
      method: 'POST',
      body: JSON.stringify({ date, batchId, status }),
    }),
  
  exportPdf: (filters: AttendanceFilters) =>
    apiFetch<{ pdfUrl: string }>(`/attendance/export${buildQueryString(filters)}`),
}

// ============ FEES ============
export const feesApi = {
  getAll: (filters?: FeeFilters) =>
    apiFetch<FeeRecord[]>(`/fees${filters ? buildQueryString(filters) : ''}`),
  
  getByStudent: (studentId: string) =>
    apiFetch<FeeRecord[]>(`/fees/student/${studentId}`),
  
  getSummary: (month?: string) =>
    apiFetch<FeeSummary>(`/fees/summary${month ? `?month=${month}` : ''}`),
  
  getOutstanding: (batchId?: string) =>
    apiFetch<FeeRecord[]>(`/fees/outstanding${batchId ? `?batchId=${batchId}` : ''}`),
  
  generate: (month: string, batchId?: string) =>
    apiFetch<{ generated: number }>(`/fees/generate`, {
      method: 'POST',
      body: JSON.stringify({ month, batchId }),
    }),
  
  recordPayment: (data: FeePaymentPayload) =>
    apiFetch<FeeRecord>(`/fees/pay`, {
      method: 'POST',
      body: JSON.stringify(data),
    }),
  
  getReceipt: (feeId: string) =>
    apiFetch<{ receiptUrl: string }>(`/fees/${feeId}/receipt`),
}

// ============ EXAMS ============
export const examsApi = {
  getAll: (filters?: ExamFilters) =>
    apiFetch<Exam[]>(`/exams${filters ? buildQueryString(filters) : ''}`),
  
  getById: (id: string) => apiFetch<Exam>(`/exams/${id}`),
  
  create: (data: ExamFormData) =>
    apiFetch<Exam>('/exams', {
      method: 'POST',
      body: JSON.stringify(data),
    }),
  
  update: (id: string, data: Partial<ExamFormData>) =>
    apiFetch<Exam>(`/exams/${id}`, {
      method: 'PUT',
      body: JSON.stringify(data),
    }),
  
  lock: (id: string) =>
    apiFetch<Exam>(`/exams/${id}/lock`, {
      method: 'POST',
    }),
  
  delete: (id: string) =>
    apiFetch<void>(`/exams/${id}`, {
      method: 'DELETE',
    }),
  
  getResults: (examId: string) =>
    apiFetch<ExamResult[]>(`/exams/${examId}/results`),
  
  saveMarks: (examId: string, marks: MarksEntryPayload[]) =>
    apiFetch<ExamResult[]>(`/exams/${examId}/marks`, {
      method: 'POST',
      body: JSON.stringify({ marks }),
    }),
  
  generateReportCard: (studentId: string, month: string) =>
    apiFetch<{ reportUrl: string }>(`/exams/report-card`, {
      method: 'POST',
      body: JSON.stringify({ studentId, month }),
    }),
}

// ============ WHATSAPP ============
export const whatsappApi = {
  getStatus: () => apiFetch<WhatsAppStatus>('/whatsapp/status'),
  
  connect: () =>
    apiFetch<WhatsAppStatus>('/whatsapp/connect', {
      method: 'POST',
    }),
  
  disconnect: () =>
    apiFetch<void>('/whatsapp/disconnect', {
      method: 'POST',
    }),
  
  getQueue: () => apiFetch<WhatsAppMessage[]>('/whatsapp/queue'),
  
  approveMessage: (id: string) =>
    apiFetch<WhatsAppMessage>(`/whatsapp/queue/${id}/approve`, {
      method: 'POST',
    }),
  
  rejectMessage: (id: string) =>
    apiFetch<WhatsAppMessage>(`/whatsapp/queue/${id}/reject`, {
      method: 'POST',
    }),
  
  retryMessage: (id: string) =>
    apiFetch<WhatsAppMessage>(`/whatsapp/queue/${id}/retry`, {
      method: 'POST',
    }),
  
  broadcast: (data: BroadcastPayload) =>
    apiFetch<{ queued: number }>('/whatsapp/broadcast', {
      method: 'POST',
      body: JSON.stringify(data),
    }),
  
  getLogs: (filters?: MessageFilters) =>
    apiFetch<WhatsAppMessage[]>(`/whatsapp/logs${filters ? buildQueryString(filters) : ''}`),
  
  getStudentMessages: (studentId: string) =>
    apiFetch<WhatsAppMessage[]>(`/whatsapp/student/${studentId}`),
}

// ============ SETTINGS ============
export const settingsApi = {
  get: () => apiFetch<AcademySettings>('/settings'),
  
  update: (data: Partial<AcademySettings>) =>
    apiFetch<AcademySettings>('/settings', {
      method: 'PUT',
      body: JSON.stringify(data),
    }),
  
  uploadLogo: (logo: File) => {
    const formData = new FormData()
    formData.append('logo', logo)
    return apiUpload<{ logoUrl: string }>('/settings/logo', formData)
  },
  
  backup: () =>
    apiFetch<{ backupPath: string }>('/settings/backup', {
      method: 'POST',
    }),
  
  restore: (backupPath: string) =>
    apiFetch<void>('/settings/restore', {
      method: 'POST',
      body: JSON.stringify({ backupPath }),
    }),
}

// ============ DASHBOARD ============
export const dashboardApi = {
  getStats: () => apiFetch<DashboardStats>('/dashboard/stats'),
}
